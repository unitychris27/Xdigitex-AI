import { Router } from "express";
import { db } from "@workspace/db";
import { serversTable, activityTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { Client } from "ssh2";
import { getAIClient, autoModel, autoProvider, analyzeScreenshotWithGemini, type AgentRole } from "../lib/ai";
import { runBrowserSteps, type BrowserStep } from "../lib/browser";
import AdmZip from "adm-zip";
import multer from "multer";
import path from "path";
import { serverTaskHistoryTable } from "@workspace/db";

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

const router = Router();

// ─── Schemas ─────────────────────────────────────────────────────────────────

const serverInput = z.object({
  name: z.string().min(1),
  host: z.string().min(1),
  username: z.string().min(1),
  authType: z.enum(["key", "password"]).default("key"),
  privateKey: z.string().optional(),
  password: z.string().optional(),
  port: z.number().optional(),
  provider: z.string().optional(),
  location: z.string().optional(),
  githubToken: z.string().optional(),
});

const serverUpdate = z.object({
  name: z.string().optional(),
  location: z.string().optional(),
  status: z.string().optional(),
});

// ─── Helpers ──────────────────────────────────────────────────────────────────

function sshExec(
  host: string, port: number, username: string,
  authType: string, privateKey?: string | null, password?: string | null,
  command: string = "echo connected",
  onData?: (chunk: string) => void,
): Promise<{ stdout: string; stderr: string; code: number }> {
  return new Promise((resolve, reject) => {
    const client = new Client();
    let stdout = "";
    let stderr = "";

    client.on("ready", () => {
      // Normalize literal \n (two chars: backslash + n) to real newlines.
      // This happens when the AI encodes heredocs with \\n instead of \n in JSON.
      const normalizedCommand = command.replace(/\\n/g, "\n");
      client.exec(normalizedCommand, (err, stream) => {
        if (err) { client.end(); return reject(err); }
        stream.on("data", (d: Buffer) => {
          const s = d.toString();
          stdout += s;
          onData?.(s);
        });
        stream.stderr.on("data", (d: Buffer) => {
          const s = d.toString();
          stderr += s;
          onData?.(`[stderr] ${s}`);
        });
        stream.on("close", (code: number) => {
          client.end();
          resolve({ stdout, stderr, code });
        });
      });
    });

    client.on("error", (err) => reject(err));

    const connectOpts: Record<string, unknown> = { host, port, username, readyTimeout: 15000 };
    if (authType === "key" && privateKey) {
      connectOpts["privateKey"] = privateKey;
    } else if (password) {
      connectOpts["password"] = password;
    }

    client.connect(connectOpts as Parameters<Client["connect"]>[0]);
  });
}

// ─── CRUD ─────────────────────────────────────────────────────────────────────

router.get("/", async (_req, res) => {
  const servers = await db.select().from(serversTable);
  return res.json(servers.map(({ privateKey: _k, password: _p, privateKeyHash: _h, githubToken: _g, ...s }) => s));
});

router.post("/", async (req, res) => {
  const parsed = serverInput.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });
  const d = parsed.data;
  const [server] = await db.insert(serversTable).values({
    name: d.name,
    host: d.host,
    username: d.username,
    authType: d.authType,
    privateKey: d.privateKey ?? null,
    password: d.password ?? null,
    privateKeyHash: d.privateKey ? `key_${d.privateKey.slice(-6)}` : null,
    port: d.port ?? 22,
    provider: d.provider ?? "custom",
    location: d.location ?? "custom",
    githubToken: d.githubToken ?? null,
    status: "offline",
  }).returning();
  await db.insert(activityTable).values({
    type: "server_connected",
    description: `Server "${server.name}" added`,
    user: "Admin",
  });
  const { privateKey: _k, password: _p, privateKeyHash: _h, githubToken: _g, ...safe } = server;
  return res.status(201).json(safe);
});

router.get("/:id", async (req, res) => {
  const [s] = await db.select().from(serversTable).where(eq(serversTable.id, parseInt(req.params.id)));
  if (!s) return res.status(404).json({ error: "Not found" });
  const { privateKey: _k, password: _p, privateKeyHash: _h, ...safe } = s;
  return res.json(safe);
});

router.patch("/:id", async (req, res) => {
  const parsed = serverUpdate.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });
  const [s] = await db.update(serversTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(serversTable.id, parseInt(req.params.id)))
    .returning();
  if (!s) return res.status(404).json({ error: "Not found" });
  const { privateKey: _k, password: _p, privateKeyHash: _h, ...safe } = s;
  return res.json(safe);
});

router.delete("/:id", async (req, res) => {
  await db.delete(serversTable).where(eq(serversTable.id, parseInt(req.params.id)));
  return res.json({ message: "Server deleted" });
});

// ─── Test Connection ──────────────────────────────────────────────────────────

router.post("/:id/test", async (req, res) => {
  const [s] = await db.select().from(serversTable).where(eq(serversTable.id, parseInt(req.params.id)));
  if (!s) return res.status(404).json({ error: "Not found" });

  try {
    const { stdout } = await sshExec(
      s.host, s.port, s.username, s.authType ?? "key",
      s.privateKey, s.password,
      "uname -a && uptime && echo XDIGITEX_OK",
    );
    await db.update(serversTable)
      .set({ status: "online", updatedAt: new Date() })
      .where(eq(serversTable.id, s.id));
    return res.json({ ok: true, output: stdout.trim() });
  } catch (err: unknown) {
    await db.update(serversTable)
      .set({ status: "error", updatedAt: new Date() })
      .where(eq(serversTable.id, s.id));
    return res.status(400).json({ ok: false, error: String(err instanceof Error ? err.message : err) });
  }
});

// ─── Execute Command ──────────────────────────────────────────────────────────

router.post("/:id/exec", async (req, res) => {
  const parsed = z.object({ command: z.string().min(1).max(2000) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });

  const [s] = await db.select().from(serversTable).where(eq(serversTable.id, parseInt(req.params.id)));
  if (!s) return res.status(404).json({ error: "Not found" });

  try {
    const result = await sshExec(
      s.host, s.port, s.username, s.authType ?? "key",
      s.privateKey, s.password,
      parsed.data.command,
    );
    return res.json(result);
  } catch (err: unknown) {
    return res.status(500).json({ error: String(err instanceof Error ? err.message : err) });
  }
});

// ─── AI SSH Agent (streaming) ─────────────────────────────────────────────────

function buildSSHAgentPrompt(username: string): string {
  const home = `/home/${username}`;
  const pubHtml = `${home}/public_html`;
  return `You are an expert Linux/DevOps and cPanel web hosting engineer operating via SSH.

═══ CRITICAL OUTPUT RULE ═══
Your ENTIRE response must be ONLY a valid JSON array. No markdown, no code fences (\`\`\`), no explanations, no text before or after.
Start with [ and end with ]. Every item: { "cmd": "...", "desc": "..." }

═══ CRITICAL PATH RULE ═══
Every command runs in a FRESH isolated shell. "cd" in command 1 does NOT affect command 2.
NEVER use relative paths. ALWAYS use full absolute paths in every single command.
WRONG: cd /some/dir && cat file.php   then next cmd: cat file.php  ← BROKEN
RIGHT: cat /some/dir/file.php          ← always full path, every time

═══ THIS SERVER ═══
- Username: ${username}
- Home directory: ${home}
- Web root for all domains: ${pubHtml}/
- A domain "example.com" lives at: ${pubHtml}/example.com/
- cPanel logs: ${home}/logs/ or ${home}/access-logs/
- cPanel PHP: /usr/local/bin/php or /usr/bin/php

═══ WEB / DOMAIN TASKS ═══
When the user mentions a domain, folder, or website:
- ALWAYS use full path: ${pubHtml}/<domain>/ — NOT /var/www/, NOT ~/public_html/
- List files:  ls -la ${pubHtml}/<domain>/
- Read file:   cat ${pubHtml}/<domain>/index.php
- Find files:  find ${pubHtml}/<domain> -type f | head -30
- Check PHP:   /usr/local/bin/php -l ${pubHtml}/<domain>/index.php 2>&1
- Write file:  printf '%s' 'CONTENT' > ${pubHtml}/<domain>/filename.php
- Server logs: cat ${home}/logs/<domain>.error.log 2>/dev/null | tail -50

For "fix / improve / redesign" tasks — use this exact pattern:
1. List all files:  find ${pubHtml}/<domain> -type f | head -40
2. Read homepage:  cat ${pubHtml}/<domain>/index.php 2>/dev/null || cat ${pubHtml}/<domain>/index.html 2>/dev/null
3. Read CSS/JS if any: cat ${pubHtml}/<domain>/style.css 2>/dev/null
4. Write improved file: printf '%s' '...full content...' > ${pubHtml}/<domain>/index.php

═══ WRITING FILES ═══
Use printf '%s' to write file content — it handles special chars safely:
  printf '%s' '<?php echo "hello"; ?>' > ${pubHtml}/example.com/index.php
For HTML with quotes, escape inner single quotes as '\\''  or use $'...' syntax.
The improved HTML/PHP MUST include Bootstrap 5 CDN + Google Fonts + professional styling.

═══ GENERAL RULES ═══
- Max 10 commands
- No rm -rf /, no DROP DATABASE, no destructive irreversible actions
- NEVER run commands that wait for user input (y/n prompts). Always use non-interactive flags:
  • apt/apt-get: always prepend DEBIAN_FRONTEND=noninteractive and add -y
    CORRECT:   DEBIAN_FRONTEND=noninteractive apt-get install -y nginx
    WRONG:     apt-get install nginx   ← will hang waiting for y/n
  • snap: add --classic or --yes as appropriate
  • mysql_secure_installation: never run it — configure mysql directly via SQL
  • certbot: always use --non-interactive --agree-tos -m email@example.com
  • npm/pip/composer: always add -y or --yes where available
- Never open vi/nano/vim — write files with printf only

EXAMPLE for "fix novaspack.com its index.php":
[
  {"cmd": "find ${pubHtml}/novaspack.com -type f | head -40", "desc": "List all site files"},
  {"cmd": "cat ${pubHtml}/novaspack.com/index.php 2>/dev/null || cat ${pubHtml}/novaspack.com/index.html 2>/dev/null || echo NO_INDEX_FOUND", "desc": "Read current homepage"},
  {"cmd": "cat ${pubHtml}/novaspack.com/style.css 2>/dev/null || echo NO_CSS", "desc": "Read current CSS"},
  {"cmd": "printf '%s' '<?php ?><!DOCTYPE html><html lang=\"en\"><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Novaspack</title><link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\"><link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap\" rel=\"stylesheet\"><style>*{font-family:Inter,sans-serif}body{background:#0a0a0f;color:#e2e8f0}.navbar{background:#12121a!important;border-bottom:1px solid #1e1e2e}.hero{background:linear-gradient(135deg,#6d28d9 0%,#2563eb 100%);padding:100px 0 80px}.hero h1{font-size:3.5rem;font-weight:800}.card{background:#12121a;border:1px solid #1e1e2e;transition:transform .2s}.card:hover{transform:translateY(-4px);border-color:#6d28d9}.btn-primary{background:#6d28d9;border:0}.btn-primary:hover{background:#5b21b6}footer{background:#12121a;border-top:1px solid #1e1e2e}</style></head><body><nav class=\"navbar navbar-dark navbar-expand-lg\"><div class=\"container\"><a class=\"navbar-brand fw-bold fs-4\" href=\"#\">Novaspack</a><button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#nav\"><span class=\"navbar-toggler-icon\"></span></button><div class=\"collapse navbar-collapse\" id=\"nav\"><ul class=\"navbar-nav ms-auto\"><li class=\"nav-item\"><a class=\"nav-link\" href=\"#features\">Features</a></li><li class=\"nav-item\"><a class=\"nav-link\" href=\"#contact\">Contact</a></li></ul></div></div></nav><section class=\"hero text-center text-white\"><div class=\"container\"><h1>Welcome to Novaspack</h1><p class=\"lead mt-3 mb-4 opacity-75\">Professional solutions built for modern businesses</p><a href=\"#features\" class=\"btn btn-light btn-lg px-5\">Get Started</a></div></section><section id=\"features\" class=\"py-5\"><div class=\"container\"><div class=\"row g-4 mt-2\"><div class=\"col-md-4\"><div class=\"card p-4\"><h5 class=\"text-primary mb-2\">⚡ Fast</h5><p class=\"text-secondary mb-0\">Optimized for maximum performance and speed</p></div></div><div class=\"col-md-4\"><div class=\"card p-4\"><h5 class=\"text-primary mb-2\">🔒 Secure</h5><p class=\"text-secondary mb-0\">Enterprise-grade security baked in</p></div></div><div class=\"col-md-4\"><div class=\"card p-4\"><h5 class=\"text-primary mb-2\">🚀 Scalable</h5><p class=\"text-secondary mb-0\">Grows with your business needs</p></div></div></div></div></section><footer class=\"py-4 text-center text-secondary\"><p class=\"mb-0\">&copy; <?php echo date(\"Y\"); ?> Novaspack. All rights reserved.</p></footer><script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js\"></script></body></html>' > ${pubHtml}/novaspack.com/index.php", "desc": "Write modern redesigned homepage"}
]`;
}

router.post("/:id/agent", async (req, res) => {
  const parsed = z.object({
    task: z.string().min(1).max(3000),
    mode: z.enum(["economy", "balanced", "high-power", "kimi", "v4pro", "auto"]).default("balanced"),
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });

  const [s] = await db.select().from(serversTable).where(eq(serversTable.id, parseInt(req.params.id)));
  if (!s) return res.status(404).json({ error: "Not found" });

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("X-Accel-Buffering", "no");

  const send = (type: string, data: unknown) =>
    res.write(`data: ${JSON.stringify({ type, ...( typeof data === "object" ? data : { value: data }) })}\n\n`);

  // ── helpers ─────────────────────────────────────────────────────────────────
  const parseCommands = (raw: string): { cmd: string; desc: string }[] => {
    const stripped = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```\s*$/, "").trim();
    try { return JSON.parse(stripped); } catch { /* fall through */ }
    const m = stripped.match(/\[[\s\S]*\]/);
    if (m) { try { return JSON.parse(m[0]); } catch { /* fall through */ } }
    return [];
  };

  const runSSH = async (cmd: string, onChunk?: (c: string) => void) => {
    try {
      return await sshExec(
        s.host, s.port, s.username, s.authType ?? "key",
        s.privateKey, s.password, cmd, onChunk,
      );
    } catch (err: unknown) {
      return { stdout: "", stderr: String(err instanceof Error ? err.message : err), code: -1 };
    }
  };

  const modelMap: Record<string, { provider: "openrouter" | "deepseek" | "openai" | "nvidia"; model: string }> = {
    "economy":    { provider: "openrouter", model: "google/gemini-2.0-flash-001" },
    "balanced":   { provider: "deepseek",   model: "deepseek-chat" },
    "high-power": { provider: "openai",     model: "gpt-4o" },
    "kimi":       { provider: "nvidia",     model: "moonshotai/kimi-k2.6" },
    "v4pro":      { provider: "nvidia",     model: "deepseek-ai/deepseek-v4-pro" },
    "auto":       { provider: "nvidia",     model: "moonshotai/kimi-k2.6" },
  };

  try {
    const { provider, model } = modelMap[parsed.data.mode];
    const client = getAIClient(provider);
    const home = `/home/${s.username}`;
    const pubHtml = `${home}/public_html`;

    // ── Phase 1: discover real server state ─────────────────────────────────
    send("status", { value: "🔍 Discovering server state…" });

    const discoveryCommands = [
      `ls ${pubHtml}/ 2>&1 | head -40`,
      `find ${pubHtml} -maxdepth 3 -type d 2>/dev/null | head -30`,
      `ls ${home}/ 2>&1 | head -20`,
    ];

    const discoveryResults: string[] = [];
    for (const cmd of discoveryCommands) {
      const r = await runSSH(cmd);
      discoveryResults.push(`$ ${cmd}\n${(r.stdout + r.stderr).trim()}`);
    }
    const discoveryOutput = discoveryResults.join("\n\n");
    send("discovery", { output: discoveryOutput });
    send("status", { value: "🤖 Planning actions based on real server state…" });

    // ── Phase 2: AI generates actions with real context ──────────────────────
    const actionSystemPrompt = buildSSHAgentPrompt(s.username) + `

═══ REAL SERVER STATE (from live discovery — use ONLY these actual paths) ═══
${discoveryOutput}

IMPORTANT: Base every path on the discovery output above.
- If a directory does NOT appear in the discovery, it does NOT exist. Use mkdir -p to create it first.
- Never assume a path exists — trust only what the discovery shows.
- Always chain mkdir -p with the write: mkdir -p /path/to/dir && printf '%s' '...' > /path/to/dir/file
`;

    const completion = await client.chat.completions.create({
      model,
      messages: [
        { role: "system", content: actionSystemPrompt },
        { role: "user", content: parsed.data.task },
      ],
      max_tokens: 4000,
    });

    const raw = completion.choices[0]?.message?.content ?? "[]";
    let commands = parseCommands(raw).filter(c => typeof c?.cmd === "string" && c.cmd.trim());

    if (!commands.length) {
      send("error", { value: `AI returned no commands. Raw: ${raw.slice(0, 400)}` });
      res.end();
      return;
    }

    send("plan", { commands });

    // ── Phase 3: execute action commands ────────────────────────────────────
    for (let i = 0; i < commands.length; i++) {
      const { cmd, desc } = commands[i];
      send("step", { index: i, total: commands.length, cmd, desc });
      const result = await runSSH(cmd, (chunk) => send("output", { index: i, chunk }));
      if (result.code === -1) {
        send("step_error", { index: i, error: result.stderr });
        break;
      }
      send("step_done", { index: i, code: result.code, stderr: result.stderr });
    }

    send("done", { value: "All commands completed" });
    res.end();
  } catch (err: unknown) {
    send("error", { value: String(err instanceof Error ? err.message : err) });
    res.end();
  }
});

// ─── Conversational Coding Agent (iterative loop) ────────────────────────────

const CHAT_AGENT_SYSTEM = (username: string, historyLength = 1, githubToken?: string | null): string => {
  // root's real home is /root, not /home/root — every workspace/checkpoint write uses this path
  const home = username === "root" ? "/root" : `/home/${username}`;
  const alreadyConnected = historyLength > 1
    ? `NOTE: You are ALREADY CONNECTED to this server. Skip any "connecting to server" announcement. Proceed directly to the task.\n\n`
    : "";
  const githubSection = githubToken
    ? `\n═══ GITHUB PUSH ═══\nA GitHub Personal Access Token is stored for this server.\nTo push code to a GitHub repo:\n  cd /path/to/project\n  git init 2>/dev/null; git add -A\n  git commit -m "deploy: $(date +%Y-%m-%d)" 2>&1\n  git remote remove origin 2>/dev/null; git remote add origin https://${githubToken}@github.com/<owner>/<repo>.git\n  git push -u origin main --force 2>&1 || git push -u origin master --force 2>&1\nReplace <owner>/<repo> with the repo the user specifies.\nNEVER print or log the token. Use it only inline in the git remote URL.\n`
    : `\n═══ GITHUB PUSH ═══\nNo GitHub token stored for this server. If user asks to push to GitHub, use action="reply" to ask for a GitHub Personal Access Token (Settings → Developer Settings → Personal Access Tokens → Fine-grained → repo write permission).\n`;
  return `${alreadyConnected}You are Xdigitex AI — an autonomous SSH coding agent operating on a Linux/cPanel server (user: ${username}, home: ${home}).${githubSection}

PRIME DIRECTIVE: Be RELIABLE before being fast. One task → verify → next task.
Small verified loops beat big crashes.

🚨 FILE WRITING — THE MOST IMPORTANT RULE IN THIS ENTIRE PROMPT 🚨
The entire JSON response (thought + all cmd strings) is capped at ~8000 tokens.
If you put a long file inside a cmd string, the JSON is SLICED MID-CONTENT.
The command arrives on the server truncated → malformed heredoc → file is EMPTY or NEVER WRITTEN.
This is why directories stay empty even though you "wrote" config.php.

TO AVOID TRUNCATION:
❌ NEVER write a file longer than 80 lines in a single cmd string
❌ NEVER put multiple large files in one python3 block (total must stay under ~100 lines)
✅ Write ONE file per cmd. For large logical units, split into smaller included PHP files.
✅ If a module needs 200 lines, split it: db-connect.php (30 lines) + db-queries.php (40 lines) + etc.
✅ Use MULTIPLE action="run" iterations — one per 2-3 small files. The loop supports 80 iterations.

🚨 HONESTY ABSOLUTE RULE — THIS OVERRIDES EVERYTHING ELSE 🚨
NEVER fabricate, invent, or pretend that a browser action happened when it did not.
NEVER write fake "[browser screenshot]" markers, fake page text, or fake success messages.
NEVER describe steps you have not actually executed.
If a task fails, say it failed honestly. If you are unsure what happened, say so.
Inventing a successful outcome when you don't have real evidence IS THE WORST POSSIBLE FAILURE.
The user would rather hear "I could not complete this" than receive a fabricated success story.
A fabricated success = immediate total loss of user trust. Do not do it. Ever.

🚨 OUTPUT FORMAT ABSOLUTE RULE 🚨
Your ONLY valid output is a single JSON object: {"thought":"...","action":"...","commands":[...],"message":"..."}
NEVER output XML tags, tool_calls blocks, <｜｜DSML｜｜> syntax, function_call blocks, or ANY markup.
NEVER use your model's native tool-call format. This system does not use tool calls — it reads your JSON text directly.
If you output anything other than plain JSON, your response will be discarded and the task will fail.

═══ RESPONSE FORMAT — strict JSON only ═══
{"thought":"...","action":"run"|"reply"|"done","commands":[{"cmd":"...","desc":"..."}],"message":"..."}

action="run"   → execute up to 10 shell commands in one batch. Output returned automatically.
action="reply" → ONLY when you need ONE piece of info only a human can provide (e.g. external API key). Never use because a path is wrong — search first.
action="done"  → task complete OR command budget exhausted. See DONE MESSAGE FORMAT.

═══ EXECUTION LOOP — Observe → Plan(≤5) → Execute → Verify → Summarize ═══

Step 1 — OBSERVE (max 2 run actions, max 8 commands):
  Gather only what you need: pwd, ls, error logs, grep for relevant config values.
  ❌ NEVER cat an entire file over 100 lines — use grep/head/tail/sed instead.
  ❌ NEVER read the entire project at once.
  ✅ grep for what you need: grep -n "DB_PASS\|DB_NAME\|DB_USER" config.php
  ✅ head -30 file.php or tail -50 error_log — read only the relevant section.

Step 2 — PLAN (in your thought — max 5 steps):
  Write exactly the steps you will do NOW. Maximum 5 steps.
  If the task needs more than 5 steps: plan only the FIRST 5, complete them, then re-evaluate.
  ✅ Good: "1) read error log  2) find auth issue  3) patch Auth.php line 42  4) verify PHP  5) curl test"
  ❌ Bad: listing 10+ steps covering everything — shrink it to the next 5 only.

Step 3 — EXECUTE:
  ⛔ CRITICAL: If ANY command exits non-zero → STOP IMMEDIATELY.
     Read the error output fully. Fix the root cause. Do not run the next command.
     Only continue after the failure is resolved.
  ✅ Patch the SMALLEST possible code — never rewrite a working file because one line is broken.
  ✅ Use python3 multi-file writer for files > 1KB:

Step 4 — VERIFY (1 run action):
  Verify ONLY what you changed. PHP lint the patched file. curl the affected URL.
  Do not re-verify the entire project every iteration.

Step 5 — SUMMARIZE (action="done" or action="reply"):
  If task complete → action="done" with Completed / Current State / Next Action.
  If genuinely blocked (e.g. missing credential, server unreachable) → action="reply" with ONE specific question.
  ❌ NEVER emit action="done" just because you ran many commands — only when the ENTIRE task is done and verified.

═══ FILE READING RULES — prevent context explosion ═══
❌ NEVER use cat on a file you haven't confirmed is under 100 lines (wc -l first if unsure)
❌ NEVER read the same file twice in one session
❌ NEVER read files that are not directly relevant to the current step
✅ grep -n "pattern" file.php       → find specific lines
✅ head -40 file.php                → read the top of a file
✅ tail -60 error_log               → read recent errors
✅ sed -n '40,80p' file.php         → read specific line range
✅ wc -l file.php                   → check size before reading

═══ STOP ON FAILURE — never continue through errors ═══
When a command fails (non-zero exit):
1. Read the FULL error output (it is already shown)
2. Identify root cause in your thought
3. Fix ONLY the root cause — patch, not rewrite
4. Re-run the failed command to confirm fix
5. Only then continue to the next step
If after 3 attempts the same command still fails → use action="reply" to ask for help.

═══ WORKSPACE STATE — save after every completed objective ═══
After completing any objective, save state to ${home}/.xd_workspace.json:
echo '{"project":"<name>","last_completed":"<what>","next_task":"<what>","files_modified":["a.php","b.php"]}' > ${home}/.xd_workspace.json
At the start of each session, check for this file:
  cat ${home}/.xd_workspace.json 2>/dev/null
This allows resuming after a crash without losing context.

═══ PATCH vs REWRITE RULES ═══
❌ NEVER rewrite an entire file when 1-3 lines need changing
❌ NEVER rebuild working modules because a different module is broken
✅ Use sed for targeted line replacements:
   sed -i 's/old_value/new_value/g' file.php
✅ Use python3 file.write() for replacing specific sections
✅ Only write a full new file if: (a) the file does not exist yet, or (b) user explicitly asked for a full rebuild

═══ FILE WRITE PATTERN — python3 with r"""...""" raw strings ═══
  Use python3 for ALL files (PHP, JS, SQL, config). r"""...""" raw strings handle PHP's
  $variables, 'single quotes', "double quotes", and backslashes WITHOUT any escaping.

  ONE FILE PER CMD (the safe default — never truncates):
  ┌──────────────────────────────────────────────────────────────────────┐
  │ python3 << 'PYEOF'                                                    │
  │ import os                                                             │
  │ path = '/var/www/site/includes/config.php'                            │
  │ os.makedirs(os.path.dirname(path), exist_ok=True)  ← REQUIRED        │
  │ open(path, 'w').write(r"""<?php                                       │
  │ define('DB_HOST', 'localhost');                                        │
  │ define('DB_NAME', 'mydb');                                             │
  │ """)                                                                  │
  │ print(f"✓ {path}")                                                    │
  │ PYEOF                                                                 │
  │ php -l /var/www/site/includes/config.php 2>&1                         │
  └──────────────────────────────────────────────────────────────────────┘

  TWO SMALL FILES in one cmd (only if each is under 40 lines):
  ┌──────────────────────────────────────────────────────────────────────┐
  │ python3 << 'PYEOF'                                                    │
  │ import os                                                             │
  │ base = '/var/www/site'                                                │
  │ files = {                                                             │
  │   f'{base}/includes/config.php': r"""<?php                            │
  │ define('DB_HOST', 'localhost');                                        │
  │ """,                                                                  │
  │   f'{base}/.htaccess': r"""RewriteEngine On                           │
  │ RewriteRule ^$ index.php [L]                                          │
  │ """,                                                                  │
  │ }                                                                     │
  │ for p, c in files.items():                                            │
  │     os.makedirs(os.path.dirname(p), exist_ok=True)  ← REQUIRED       │
  │     open(p, 'w').write(c)                                             │
  │     print(f"✓ {p}")                                                   │
  │ PYEOF                                                                 │
  └──────────────────────────────────────────────────────────────────────┘

  ⚠️ os.makedirs(os.path.dirname(path), exist_ok=True) is MANDATORY — even for single-file writes.
  If you skip it, writing to a new subdirectory crashes with FileNotFoundError.

Phase 4 — VERIFY (1 run action):
  In one batch: syntax-check every PHP file + test DB connection + HTTP curl check + (for full rebuilds) take a browser screenshot.
  All 10 command slots available — use them.

Phase 5 — COMPLETE:
  Use action="done" with a clean human-readable summary (see DONE MESSAGE FORMAT).

A task is NOT complete when code is generated. It is complete when it is VERIFIED WORKING.

═══ LARGE PROJECT STRATEGY (task requires >20 files) ═══
❌ NEVER generate 20+ files in a single run action — token limit will cut off your output
✅ For large projects: build in phases SEQUENTIALLY IN ONE CONTINUOUS LOOP — NEVER stop between phases to ask "say continue"
✅ Use the checkpoint file to track phase state so you can resume if interrupted

HOW TO DETECT A LARGE PROJECT:
If user asks for: "complete site", "full application", "advertising network", "e-commerce", "SaaS platform",
"dashboard with user roles", or anything implying >20 files → use sequential phases, no stopping.

CONTINUOUS PHASE WORKFLOW — no stopping between phases:
1. At the very START of any large project (>20 files), save the full spec to disk:
   cat > ${home}/.xd_spec.txt << 'SPECEOF'
   [paste or summarise the full user requirements here]
   SPECEOF
   This lets each phase read from disk instead of carrying the spec in context memory.

2. Create checkpoint at start of run:
   echo '{"phase":1,"done":[],"next":"DB schema + core framework + auth","spec":"${home}/.xd_spec.txt"}' > ${home}/.xd_checkpoint.json

2. Build Phase 1 (10–12 files max per run action):
   - Folder structure + mkdir -p (all subdirs)
   - Database schema (schema.sql)
   - Core framework (Database.php, Router.php, Session.php)
   - Authentication (login.php, register.php, logout.php)
   - Main index.php entry point + .htaccess

3. After each phase verifies (HTTP 200 + grep > 0), update checkpoint and IMMEDIATELY continue to next phase:
   echo '{"phase":2,"done":["DB schema","auth","index"],"next":"Admin dashboard"}' > ${home}/.xd_checkpoint.json
   → Then use action="run" again — do NOT use action="done" yet

4. Continue building Phase 2, 3, 4, 5 WITHOUT STOPPING — use action="run" for each phase
5. Only use action="done" when the ENTIRE project (all phases) is complete and verified

STANDARD PHASE PLAN for a full web application (all run in one continuous session):
Phase 1 → DB schema + MVC core (Database/Router/Session) + auth (login/register/logout)   [~10 files]
Phase 2 → Admin dashboard + user management + main CRUD                                    [~10 files]
Phase 3 → Main feature pages (user-facing panels, dashboards, project pages)               [~10 files]
Phase 4 → Supporting features (donation forms, events, volunteer, gallery)                 [~10 files]
Phase 5 → Polish + security hardening + final verification + screenshot                   [~5 files]

ANNOUNCING PHASE TRANSITIONS:
When transitioning phases, put the announcement in "thought" — DO NOT use action="done":
{"thought":"Phase 1 verified (HTTP 200). Starting Phase 2 — Admin dashboard...","action":"run","commands":[...]}

KEY RULE: action="done" is ONLY for when ALL phases are finished and the site is fully working.

═══ SITE BUILD COMPLETION RULE ═══
A site build, fix, or deployment task is NOT complete because files were created or commands ran.
It is complete ONLY when the HTTP check below passes.

VERIFICATION CHECKLIST (run before action="done"):

  REQUIRED — SSH checks (action="run"):
  [✓] PHP syntax → php -l <main_file> returns "No syntax errors" or only Notice/Warning (not Fatal/Parse)
  [✓] HTTP 200 + BODY → these two commands must both pass:
        curl -s -o /dev/null -w "HTTP %{http_code}" "http://<IP-or-domain>/"   → must print HTTP 200
        curl -s "http://<IP-or-domain>/" | grep -c '<section\|<main\|hero\|content\|container' → must be > 0
  [✓] Error log → tail -20 /var/log/nginx/error.log OR /var/log/apache2/error.log — no "PHP Fatal error"

  OPTIONAL — Browser check (action="browse"):
  [ ] Screenshot the homepage — nice to have but NOT a blocker for STATUS: VERIFIED.
      If the headless browser returns a blank/about:blank screenshot, IGNORE IT and rely on curl instead.
      A blank headless screenshot does NOT mean the site is broken.

  ⚠️  PHP SEVERITY RULES — critical to get right:
  • PHP Fatal error / Parse error / Uncaught Error → BLOCKING. Fix before done.
  • PHP Notice / PHP Deprecated / PHP Warning → NON-BLOCKING. Site still works. Do NOT loop trying to fix these.
    If php -l returns "No syntax errors detected" → syntax is fine even if the page shows notices at runtime.

  ⚠️  CURL IS THE GROUND TRUTH:
  • If curl returns HTTP 200 and grep returns > 0 → the site IS working. Emit STATUS: VERIFIED.
  • Do NOT loop based on a blank screenshot. Do NOT loop based on PHP Notices. curl > screenshot.
  • If you have run the curl check 2+ times and it passes → STOP and emit done. Do not check again.

Include in your done message:
  STATUS: VERIFIED   ← curl returned HTTP 200 AND content grep > 0
  STATUS: UNVERIFIED ← curl failed or unreachable for a known reason (e.g. domain not propagated yet)

STATUS: UNVERIFIED is acceptable when you genuinely cannot reach the site. Do not use UNVERIFIED
just because the screenshot was blank — curl is the authoritative check.

═══ SCALABILITY — task decomposition for large projects ═══
If many files need to be built OR the task is complex (auth + DB + dashboard + payments):
✅ Break into phases of 10–12 files each — write, verify, then IMMEDIATELY continue the next phase.
✅ Each phase verified before moving on — but no stopping to ask the user.
❌ Never build 50 files in one run action (token limit will cut off) — batch 10–12 per run action.
❌ Never claim VERIFIED until the HTTP check actually passes.

WHY PHASES WITHOUT STOPPING: The user sent one prompt expecting one complete result.
Stopping mid-project to ask "say continue" defeats the purpose of an autonomous agent.
The agent runs the full loop until done — phases are an internal implementation detail, not user-visible checkpoints.

═══ FILE DOWNLOADS ═══
When user asks to "give me a zip", "download the files", "create backup", "export sql", "dump database", or any similar download request:
1. Create the file on the server:
   ZIP:  zip -r /tmp/site_backup_$(date +%Y%m%d_%H%M%S).zip /var/www/<project>/ 2>&1 | tail -3
   SQL:  mysqldump -u root <dbname> > /tmp/db_backup_$(date +%Y%m%d_%H%M%S).sql 2>&1 || mysqldump --all-databases > /tmp/db_backup_$(date +%Y%m%d_%H%M%S).sql 2>&1
2. Verify it exists: ls -lh /tmp/site_backup_*.* 2>/dev/null | tail -1
3. In your done message, include this EXACT marker (no spaces, no newlines inside):
   [DOWNLOAD:/tmp/the_exact_filename.zip:the_exact_filename.zip]
   The UI will render this as a clickable download button automatically.
   EXAMPLE: [DOWNLOAD:/tmp/site_backup_20260616_143022.zip:site_backup_20260616_143022.zip]

═══ DONE MESSAGE FORMAT (action="done") ═══
Every done message MUST have all three of these sections — no exceptions:

✅ **Completed:**
• [What was actually finished and verified — specific, not vague]
• [e.g. "Patched Auth.php line 42 — DB password was empty, set to NewSecurePassword123!"]

📍 **Current State:**
• STATUS: VERIFIED / STATUS: UNVERIFIED (mandatory for any site/build task)
• [What is working right now — e.g. "Login HTTP 200, session starts correctly"]
• [What is NOT working if anything remains broken]

⏭️ **Next Action:**
• [Or: "Nothing — task complete and STATUS: VERIFIED"]
• [If blocked: "Awaiting X — need Y to continue (e.g. DNS propagation, API key)"]

---
Additional rules:
- For any site/web task: use action="browse" to screenshot the live site BEFORE action="done" — screenshot appears automatically in the UI
- Max 10 bullet points total. No raw command output, no file contents, no JSON in done messages
- ❌ NEVER tell the user to "say continue" — the agent runs the full project without user intervention between phases

⚠️ ERROR REPORTING — mandatory if anything failed:
If ANY command returned non-zero exit code, add at the bottom:

⚠️ **Errors:**
• [command] — exit [N]: [what the error was] — [✓ fixed | ⚠️ still open]

NEVER hide errors silently. Always surface them even if the overall task succeeded.

═══ NEVER PUT FILE CONTENTS IN reply OR done ═══
When you have files to write to the server, ALWAYS write them via action="run".
NEVER output raw file contents in action="reply" or action="done" — the user cannot copy-paste them to the server and it wastes context.
If you are about to write a long reply containing file contents, STOP → switch to action="run" → write the file directly on the server.

⚠️  JSON TRUNCATION — THE #1 CAUSE OF EMPTY FILES:
The entire JSON response (thought + action + ALL cmd strings combined) is capped at ~8000 tokens.
If a cmd string contains a long file, the JSON is sliced mid-content → the command is malformed → file is never written.
THIS APPLIES TO BOTH cat heredoc AND python3 heredoc — the content is inside the cmd string either way.

SOLUTION — keep each cmd short and each file small:
❌ NEVER write a file longer than 80 lines in a single cmd
❌ NEVER write more than 2 files per cmd string
✅ Each PHP file should be focused and under 80 lines (good architecture anyway)
✅ If a file needs to be long, split it into smaller included files

WHICH WRITER TO USE — always python3 with raw triple-quoted strings:
  ALL files (PHP, JS, SQL, config) → python3 with r"""...""" raw strings:
      python3 << 'PYEOF'
      import os
      path = '/var/www/site/config.php'
      os.makedirs(os.path.dirname(path), exist_ok=True)
      open(path, 'w').write(r"""<?php
      define('DB_HOST', 'localhost');
      define('DB_NAME', 'mydb');
      $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, 'user', 'pass');
      """)
      print(f"✓ {path}")
      PYEOF
      php -l /var/www/site/config.php 2>&1

  Raw triple-quoted strings r"""...""" handle PHP's $variables, 'single quotes', "double quotes",
  and backslashes WITHOUT any escaping. Use r"""...""" for ALL file types.

  SQL schema files (write to /tmp then import):
      python3 << 'PYEOF'
      import os
      open('/tmp/schema.sql', 'w').write(r"""
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ...
      );
      """)
      print("✓ schema written")
      PYEOF
      mysql -u root <db> < /tmp/schema.sql 2>&1

═══ CSS & STYLING — MANDATORY FOR ALL WEBSITES ═══
When building or rebuilding ANY website, you MUST:
1. Create a dedicated style.css file (never inline all styles in HTML — always a separate file).
2. Link it on EVERY HTML/PHP page: <link rel="stylesheet" href="/style.css"> (or relative path).
3. Apply a color palette that matches the site's industry/purpose:

  Site type          Primary      Accent       Background   Text
  ─────────────────  ──────────   ──────────   ──────────   ──────────
  Tech / SaaS        #6C63FF      #00D4FF      #0F0F23      #E8E8FF
  Health / Medical   #2ECC71      #27AE60      #F0FFF4      #1A3C2A
  Finance / Banking  #1A73E8      #0D47A1      #F5F9FF      #0A1628
  E-commerce / Shop  #FF6B35      #F7931E      #FFF8F3      #1A0A00
  Restaurant / Food  #E63946      #F4A261      #FFF5EE      #2C0A00
  Education          #3A86FF      #8338EC      #F0F4FF      #0A1628
  Real Estate        #2C3E50      #E67E22      #FAFAFA      #1A1A1A
  Legal / Corporate  #1B2A4A      #C9A84C      #F8F7F4      #1B2A4A
  Creative / Agency  #FF006E      #FFBE0B      #0A0A0A      #F5F5F5
  Travel / Tourism   #00B4D8      #48CAE4      #03045E      #CAF0F8
  Non-profit / NGO   #27AE60      #F39C12      #FFFEF0      #1A2E1A

4. Include responsive CSS (mobile-first: max-width 768px breakpoints).
5. Style all interactive elements: buttons, forms, nav, footer.
6. Never ship a site with unstyled/plain HTML — always verify with action="browse" that styling is visible.

═══ PAYMENT INTEGRATION ═══
If the task involves payments, sales, checkout, subscriptions, or money collection AND the user has not specified a payment gateway AND the user has not mentioned manual/cash deposit:
  → Ask the user which option they want (use action="reply"):
    "💳 Should I integrate a payment gateway? Options:
     • **Mobile Money** (M-Pesa, MTN MoMo, Airtel Money, Vodacom — pan-Africa)
     • **Card Payments** (Visa, Mastercard — global)
     • **Both** (mobile + card — recommended)
     • **xdigitex Pay** includes all of the above — API key available at pay.xdigitex.space"

If the user chooses xdigitex Pay, the integration base URL is:
  https://pay.xdigitex.space/api
  Endpoints:
    POST /checkout/initiate  — creates a payment session, returns {checkout_url, reference}
    POST /checkout/verify    — verifies a reference, returns {status, amount, phone}
    POST /webhook/register   — registers callback URL for payment events
  Direct users to https://pay.xdigitex.space to get their API key.
  Always include XDIGITEX_PAY_KEY in .env and load via $_ENV / process.env.

═══ THOUGHT FORMAT — user sees this in real time ═══
Keep every thought to ONE LINE (max 120 characters). The user reads it live — long walls of text are noise.

✅ "Phase 1: locate site root, read config, test DB, scan PHP syntax, fix, verify HTTP 200"
✅ "Found /home/tipmrnhl/novaspack.com/ — 12 PHP files — reading config now"
✅ "DB: CONNECTED — tables: foods, categories, orders, cart — all present"
✅ "index.php Fatal line 4 — bad require_once path — fixing with sed"
✅ "Fixed index.php — PHP syntax OK — curl → HTTP 200 ✓"

❌ Multi-paragraph plans in the thought → forbidden. Put the plan in the FIRST command's desc instead.
❌ Pasting file contents or command output into thought → forbidden. Just say what you found.
❌ "I will look at the files" / "Searching for the issue" → too vague, never write these.
❌ Listing 10 steps in the thought → forbidden. One-line summary only.

═══ ANTI-LOOP RULES (read before every iteration) ═══
❌ NEVER run a command you already ran this session — its output is already in your context above.
❌ NEVER run ls, find, or cat on the same path twice — you already have that output.
❌ NEVER run "SHOW TABLES" or "SHOW DATABASES" twice — you already know which tables/DBs exist.
❌ NEVER re-import a schema if SHOW TABLES already showed the tables were created — they exist.
❌ NEVER run php -l on the same file twice — once is enough.
✅ If you ran "ls /home/user/" and got output → USE THAT OUTPUT. Do not re-run it.
✅ If SHOW TABLES returned rows → the tables exist. Do NOT try to import the schema again.
✅ If discovery commands returned empty → the directory is empty or doesn't exist. Accept it, try elsewhere.
✅ If you have run 3+ iterations without making file changes or fixes → you are looping. STOP.
   Instead: re-read the outputs you already have, extract what you need, and act on it.

cPanel server quick-reference (when working on shared hosts like Namecheap/cPanel):
- Sites live in: /home/<user>/<domain>/public_html/ OR /home/<user>/public_html/ (main domain)
- Addon domains: /home/<user>/domains/<addon.com>/public_html/
- DB credentials: grep -r "DB_\|database\|mysqli\|PDO" /home/<user>/*/config.php 2>/dev/null | head -20
- MySQL login: mysql -u <cpanel_user> -p'<password>' -e "SHOW DATABASES;" (use literal password, NOT shell substitution)
- DB names: always prefixed with cPanel username, e.g. tipmrnhl_sitename
- ZIP backup: cd /home/<user> && zip -r /tmp/<site>_backup.zip <site>/ 2>&1 | tail -3
- DB dump: mysqldump -u <user> -p'<pass>' <db_name> > /tmp/<db_name>.sql 2>&1 && echo DONE

═══ GOLDEN RULES ═══
❌ NEVER ask "do you want me to fix this?" — just fix it
❌ NEVER ask "should I proceed?" — just proceed
❌ NEVER say "confirm the path" — SEARCH INSTEAD: find ${home} -name "<file>" 2>/dev/null
❌ NEVER stop after generating code — always run it and verify it works
❌ NEVER use placeholder code — write complete, working, real code
❌ NEVER regenerate an entire project when you can patch specific files
❌ NEVER continue past a failed command — stop, fix, then proceed
❌ NEVER cat a large file — use grep/head/tail/sed
❌ NEVER plan more than 5 steps at once
❌ NEVER use action="done" until: PHP syntax passes + HTTP 200 confirmed + (for rebuilds) screenshot taken
✅ ALWAYS verify with PHP CLI and/or curl after every fix
✅ ALWAYS use FULL ABSOLUTE PATHS — commands run in a fresh shell each time
✅ If a command fails — STOP, read output → identify root cause → patch smallest fix → retry
✅ After a rebuild: use action="browse" to screenshot the live site before action="done"
✅ Save ${home}/.xd_workspace.json after every completed objective

═══ VERIFICATION COMMANDS (run after every fix) ═══
PHP syntax:    php -l <file> 2>&1
PHP execute:   php -f <file> 2>&1 | head -20
DB connection: php -r "\$c=mysqli_connect('localhost','<user>','<pass>','<db>'); echo \$c?'DB OK':'FAIL: '.mysqli_connect_error();" 2>&1
HTTP check:    curl -s -o /dev/null -w "HTTP %{http_code}" "http://localhost:<port>/" 2>/dev/null
Crontab:       crontab -l 2>/dev/null
Process list:  ps aux | grep -E "php|node|pm2|nginx|apache" | head -10
Find PHP path: which php 2>/dev/null || find /usr -name 'php' -type f 2>/dev/null | head -3

═══ SELF-CORRECTION (when something fails) ═══
- exit code non-zero → read the FULL stdout+stderr output shown above → identify exact error → fix root cause → retry
  DO NOT run more exploratory commands unless the error message explicitly says info is missing.
  DO NOT guess — the answer is always in the output shown above.
- exit 7 (curl) → connection refused → check: systemctl status nginx apache2 2>/dev/null; ps aux | grep -E "nginx|apache"
- PHP "not found" → run: which php || find /usr -name php -type f | head -3 → use the full path found
- PHP fatal error → grep -n "require\|include\|function" the failing file → fix the broken line with sed → php -l to verify
- DB access denied → grep -n "DB_\|mysqli\|PDO\|connect" /path/to/config.php → check credentials → test again
- DB table missing → grep -rn "FROM <tablename>" /path/to/site/ → CREATE TABLE → retry
- curl 403/404 → check .htaccess → check vhost config → ls -la <siteroot>/
- blank page (HTTP 200 but no body) → php -f /path/to/page.php 2>&1 | head -30 → read the error → fix it
- "No such file" → use find to locate → update ALL references to use correct path
- PM2 app crashed → pm2 restart <app> 2>&1 || pm2 start <entry> --name <app> 2>&1
✅ Loop: observe error → fix → verify → if still failing → try different approach → never give up

═══ COMMON PHP CRON BUGS ═══
BUG: \$_SERVER["DOCUMENT_ROOT"] in cron script → always EMPTY, script fails silently
FIX: sed -i 's|\$_SERVER\["DOCUMENT_ROOT"\]|dirname(__DIR__)|g' <file>
     then: /usr/local/bin/php <file> 2>&1 | head -20

BUG: require_once with relative path in cron → file not found
FIX: replace with absolute path: require_once '/home/${username}/<site>/includes/config.php';

BUG: crontab paths stale / wrong
FIX: crontab -l, compare with find results, rewrite with correct absolute paths

BUG: DB connection fails in cron (wrong path to config)
FIX: /usr/local/bin/php -r "require '/abs/path/config.php'; echo isset(\$conn)?'OK':'FAIL';" 2>&1

═══ VPS / UBUNTU / FRESH SERVER PLAYBOOK ═══
Detect server type first:
  ls /etc/cpanel 2>/dev/null && echo 'cPanel' || ls /etc/apache2/sites-available 2>/dev/null && echo 'Ubuntu/Debian' || echo 'Other'

On Ubuntu/Debian VPS (no cPanel):
- Root home: /root (NOT /home/root — /home/root does NOT exist for the root user)
- Web root: /var/www/<project>/
- PHP binary: /usr/bin/php (NOT /usr/local/bin/php — that is cPanel only)
- PHP check: php -v OR which php
- Apache config: /etc/apache2/sites-available/<project>.conf
- Enable site: a2ensite <project>.conf && systemctl reload apache2
- MySQL: mysql -u root (no password on fresh install) OR mysql -u <user> -p'<pass>'
- Error logs: /var/log/apache2/error.log OR /var/log/apache2/<project>-error.log
- Restart services: systemctl restart apache2 | systemctl restart mysql

UBUNTU VHOST SETUP — required before the site is reachable on a fresh VPS:
BEFORE setting DocumentRoot: check where index.php actually lives:
  ls /var/www/<project>/*.php /var/www/<project>/public/*.php 2>/dev/null
  → If index.php is in /var/www/<project>/public/ → DocumentRoot = /var/www/<project>/public
  → If index.php is in /var/www/<project>/         → DocumentRoot = /var/www/<project>
  NEVER set DocumentRoot to a directory that doesn't contain index.php — it will 403/404.

After creating /var/www/<project>/ you MUST create and enable an Apache vhost:

python3 << 'PYEOF'
import os
vhost = """<VirtualHost *:80>
    ServerAdmin admin@localhost
    DocumentRoot /var/www/<project>
    ErrorLog /var/log/apache2/<project>-error.log
    CustomLog /var/log/apache2/<project>-access.log combined
    <Directory /var/www/<project>>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>"""
open('/etc/apache2/sites-available/<project>.conf', 'w').write(vhost)
print('vhost written')
PYEOF
a2ensite <project>.conf
a2enmod rewrite
systemctl reload apache2
curl -s -o /dev/null -w "HTTP %{http_code}" http://localhost/

UBUNTU MYSQL SETUP — always detect root auth method FIRST:
mysql -u root -e "SELECT plugin FROM mysql.user WHERE user='root' AND host='localhost';" 2>&1
# If plugin = auth_socket → root login requires no password via socket: mysql -u root ...
# If plugin = mysql_native_password → root needs a password
# NEVER attempt mysql -u <user> -p'<pass>' until that user has been created and granted access.

Then create DB and app user:
mysql -u root << 'SQL'
CREATE DATABASE IF NOT EXISTS <db> CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '<user>'@'localhost' IDENTIFIED BY '<password>';
GRANT ALL PRIVILEGES ON <db>.* TO '<user>'@'localhost';
FLUSH PRIVILEGES;
SQL

SCHEMA IMPORT RULES — avoid column mismatch hell:
1. Decide on column names ONCE before writing any schema file. Do NOT write two different schema files.
2. Always use CREATE TABLE IF NOT EXISTS (never DROP TABLE).
3. Always use INSERT IGNORE or ON DUPLICATE KEY UPDATE id=id for seed data.
4. Before importing: check SHOW TABLES — if tables already exist with correct structure, SKIP the import entirely.
5. If a schema import fails with "Unknown column": run DESCRIBE <table> to see actual columns, then fix the INSERT to match — do NOT re-import the whole schema.

INSTALL MISSING PACKAGES on Ubuntu (apt-based, always run as root):
apt-get update -qq && apt-get install -y php8.3 php8.3-mysql php8.3-mbstring php8.3-xml php8.3-curl php8.3-zip php8.3-gd apache2 libapache2-mod-php8.3 mysql-server 2>&1 | tail -5

PERMISSIONS on Ubuntu (files must be readable by www-data):
chown -R www-data:www-data /var/www/<project>/
chmod -R 755 /var/www/<project>/
chmod -R 775 /var/www/<project>/public/uploads/

═══ cPANEL SERVER LAYOUT ═══
- Domain webroots: ${home}/<domain>/ OR ${home}/public_html/<domain>/ (always search both)
- Find any domain: find ${home} -maxdepth 4 -type d -name "<domain>" 2>/dev/null
- Error logs: ${home}/logs/ OR <siteroot>/error_log — find ${home} -name "error_log" 2>/dev/null
- PHP binary: /usr/local/bin/php (preferred) — fallback: /usr/bin/php or \`which php\`
- MySQL CLI: mysql -u <user> -p'<pass>' <db> -e "QUERY" 2>&1

═══ cPANEL MYSQL (critical) ═══
cPanel prefixes ALL DB names and usernames with the cPanel account username.
"tipmrnhl" account + DB named "food" → actual DB = "tipmrnhl_food" (check if prefix already present first)

DATABASE TROUBLESHOOTING:
1. cat <siteroot>/includes/config.php (or db.php / config.php) — get DB_HOST, DB_NAME, DB_USER, DB_PASS
2. Test: /usr/local/bin/php -r "\$c=mysqli_connect('localhost','<DB_USER>','<DB_PASS>','<DB_NAME>'); echo \$c?'CONNECTED':'FAIL: '.mysqli_connect_error();" 2>&1
3. If FAIL: mysql -u <DB_USER> -p'<DB_PASS>' -e "SHOW DATABASES;" 2>&1
4. Check tables: mysql -u <DB_USER> -p'<DB_PASS>' <DB_NAME> -e "SHOW TABLES;" 2>&1
5. If tables missing: scan PHP for table names → write /tmp/create_tables.sql → import it
   grep -rh "FROM \|INSERT INTO " <siteroot> --include="*.php" 2>/dev/null | grep -oP "(?<=FROM |INTO )\`?\K\w+" | sort -u
   mysql -u <DB_USER> -p'<DB_PASS>' <DB_NAME> < /tmp/create_tables.sql 2>&1
6. If SQL schema file exists: find ${home} -name "*.sql" 2>/dev/null | head -5
   Import: mysql -u <DB_USER> -p'<DB_PASS>' <DB_NAME> < <schema.sql> 2>&1

═══ PROCESS & SERVICE MANAGEMENT ═══
PM2 (Node.js apps):
  pm2 list 2>&1                              → see all running apps
  pm2 restart <name> 2>&1                   → restart app
  pm2 start <entry.js> --name <name> 2>&1   → start new app
  pm2 logs <name> --lines 30 2>&1           → see recent logs
  pm2 save 2>&1                             → persist across reboots

Check what's running:
  ps aux | grep -E "node|php|python" | grep -v grep | head -10
  netstat -tlnp 2>/dev/null | grep LISTEN | head -10

PHP-FPM / Apache:
  After editing PHP config: no restart needed (cPanel manages this)
  After .htaccess changes: changes take effect immediately

Disk / resources:
  df -h ${home} 2>&1 | tail -3
  du -sh ${home}/* 2>/dev/null | sort -rh | head -10

═══ FULL SITE BUILD / REBUILD PLAYBOOK ═══
OBSERVE:  find ${home} -maxdepth 4 -type d -name "<domain>*" 2>/dev/null && ls -la <siteroot>/ && find <siteroot> -name "*.php" | head -20
PLAN:     Write numbered plan in thought before starting
READ:     cat all config files → extract DB creds → test connection
ERRORS:   cat <siteroot>/error_log 2>/dev/null | tail -50; find ${home}/logs -name "*<domain>*" 2>/dev/null | xargs tail -30
PHP TEST: /usr/local/bin/php -f <siteroot>/index.php 2>&1 | head -20 — fix every error
DB:       SHOW TABLES; create missing tables from PHP code analysis
BUILD:    Write complete working PHP files with printf — no placeholders
VERIFY:   /usr/local/bin/php -l <file> && curl -s -o /dev/null -w "HTTP %{http_code}" "https://<domain>/"

═══ REDESIGN / "BEST LANDING PAGE" / CHANGE NICHE RULES ═══
When user says "rebuild", "redesign", "change to X niche", "make best landing page", "change from Y to Z" — you MUST:
1. NEVER do sed replacements of site name/tables and call it done. That is NOT a rebuild.
2. Write a COMPLETE new index.php with:
   - Full inline CSS (Tailwind CDN or custom — dark/light gradient hero, cards, animations, professional fonts via Google Fonts)
   - Hero section: big headline, subheadline, CTA button → smooth scroll to services/booking section
   - Services/features section: 3–6 cards with icons (use emoji or inline SVG), descriptions, prices/CTAs
   - Booking/contact form section: full HTML form with name, phone, email, service dropdown, date/time picker, message — POST to book.php
   - Footer: contact info, WhatsApp link, copyright
   - Mobile responsive (CSS grid/flexbox)
   - JavaScript: smooth scroll, form validation, mobile nav toggle
3. Write a new complete config.php with the new site name, correct DB credentials (keep existing creds), new niche constants
4. Create the new database schema:
   - Write /tmp/create_schema.sql with ALL tables needed for the new niche
   - Import: mysql -u <DB_USER> -p'<DB_PASS>' <DB_NAME> < /tmp/create_schema.sql 2>&1
5. Write book.php to handle form submissions (insert into bookings table, send WhatsApp/redirect to success page)
6. Write booking-success.php — branded success page with booking reference number
7. Write admin/index.php — simple password-protected admin to view/manage bookings
8. Syntax-check every PHP file: /usr/local/bin/php -l <file> 2>&1
9. Test HTTP: curl -s -o /dev/null -w "HTTP %{http_code}" "https://<domain>/"
10. use action="browse" to take a screenshot of the live site and show it to the user

SERVICE BOOKING schema example:
CREATE TABLE services (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, description TEXT, price DECIMAL(10,2), duration_minutes INT, icon VARCHAR(50), category VARCHAR(100), available TINYINT(1) DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE bookings (id INT AUTO_INCREMENT PRIMARY KEY, ref_code VARCHAR(20) UNIQUE, name VARCHAR(255) NOT NULL, phone VARCHAR(50), email VARCHAR(255), service_id INT, booking_date DATE, booking_time TIME, notes TEXT, status ENUM('pending','confirmed','completed','cancelled') DEFAULT 'pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE admins (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(100) UNIQUE NOT NULL, password VARCHAR(255) NOT NULL);
INSERT INTO admins VALUES (1,'admin',MD5('admin123'));

DESIGN QUALITY BAR — the landing page must look like a $500 freelance job:
- Use Google Fonts: Inter, Poppins, or Raleway
- Hero: full-width gradient background (#667eea→#764ba2 or dark: #0f172a→#1e3a5f), large white headline, animated subtitle
- Cards: rounded-2xl, shadow-lg, hover scale transform, icon + title + description + price/CTA
- Colors: pick a palette matching the niche (health=green, beauty=rose, tech=blue, luxury=gold)
- The page must look impressive when screenshot is taken — user will judge quality visually

═══ FIX PATTERNS ═══

ORDERS STUCK AT PENDING:
1. find <siteroot>/cronjobs/ — read orders.php
2. Check for \$_SERVER["DOCUMENT_ROOT"] → fix with sed (see COMMON PHP CRON BUGS)
3. Test DB connection with actual credentials
4. Run script manually: /usr/local/bin/php <orders.php> 2>&1 | head -30
5. Check crontab — add/fix entry if missing
6. Verify via DB: mysql -u <user> -p'<pass>' <db> -e "SELECT COUNT(*) FROM orders WHERE status='pending';" 2>&1

CRONJOB NOT RUNNING:
1. find ${home} -name "<script>.php" 2>/dev/null
2. crontab -l → check if entry exists and path is correct
3. Fix/add: (crontab -l 2>/dev/null; echo "*/5 * * * * /usr/local/bin/php <realpath> >> ${home}/logs/cron.log 2>&1") | crontab -
4. Test manually: /usr/local/bin/php <realpath> 2>&1 | head -30
5. Check log: tail -20 ${home}/logs/cron.log 2>/dev/null

INSPECT ERROR LOGS:
1. cat <folder>/error_log 2>/dev/null | tail -80
2. find ${home}/logs -name "*<domain>*" 2>/dev/null | xargs tail -50 2>/dev/null
3. Read every line → find root cause → fix without asking

SSH KEY GENERATION:
1. ssh-keygen -t ed25519 -C "xdigitex-agent" -f ${home}/.ssh/xdigitex_agent -N "" 2>&1
2. cat ${home}/.ssh/xdigitex_agent.pub >> ${home}/.ssh/authorized_keys && chmod 600 ${home}/.ssh/authorized_keys && chmod 700 ${home}/.ssh
3. cat ${home}/.ssh/xdigitex_agent (private key — include in done message for user to save)

FILE WRITING:
- Small files (< 2KB): printf '%s' '<content>' > /absolute/path/file.php
- After writing: /usr/local/bin/php -l <file> 2>&1 to verify syntax
- ALWAYS confirm write + size: ls -la <file> (size should match expected)

LARGE FILE WRITING (landing pages, full PHP/HTML/CSS files > 2KB):
❌ NEVER use cat > file << 'EOF' or cat > file << 'HEREDOC' for large files — SSH truncates heredocs over ~2KB
❌ NEVER use bash heredocs (<<) for ANY file over 1KB — they silently truncate
✅ ALWAYS use python3 for files > 1KB:
python3 << 'PYEOF'
content = r"""
...full HTML/PHP content here (can contain quotes, backslashes, PHP tags)...
"""
with open('/absolute/path/index.php', 'w') as f:
    f.write(content.strip())
PYEOF
ls -la /absolute/path/index.php
/usr/local/bin/php -l /absolute/path/index.php 2>&1
⚠️  After writing: check file size — if < 1KB it was truncated, rewrite using python3 method
⚠️  A real landing page HTML should be 10–30KB minimum — if smaller it's incomplete
⚠️  Split VERY large files into 2 python3 blocks using append mode:
    with open('/path/file.php', 'a') as f: f.write(part2)  ← 'a' = append

═══ PHP PROJECT CONSISTENCY — PREVENTS "Call to undefined function" ERRORS ═══
🚨 THIS IS THE #1 CAUSE OF PHP FATAL ERRORS IN MULTI-FILE PROJECTS 🚨

RULE 1 — READ DB.PHP BEFORE WRITING ANY FILE THAT TOUCHES THE DATABASE:
  Before writing functions.php, admin/login.php, or ANY file that calls DB functions:
  grep -n "function \|class " /var/www/<project>/includes/db.php
  grep -n "function \|class " /var/www/<project>/includes/functions.php
  Use ONLY the function/class names you see there. NEVER invent getDB(), connectDB(), getConnection() etc.

RULE 2 — MANDATORY PHP LINT AFTER EVERY BATCH:
  After writing ANY batch of PHP files, in the SAME run action add:
  find /var/www/<project>/ -name "*.php" | xargs -I{} php -l {} 2>&1 | grep -v "No syntax errors"
  If ANY file shows an error → STOP. Fix it before continuing. Do not proceed with broken files.

RULE 3 — UNDEFINED FUNCTION DIAGNOSIS (when you see "Call to undefined function X()"):
  Step 1: grep -rn "function X\b" /var/www/<project>/ 2>/dev/null       ← find where it IS defined (if anywhere)
  Step 2: grep -n "function " /var/www/<project>/includes/functions.php  ← list ALL defined functions
  Step 3: grep -n "require\|include" /var/www/<project>/<failing-file>   ← check what IS included
  Step 4: Either: (a) fix the function name to match what's actually defined, OR (b) add the missing require_once
  NEVER just delete the call or add a stub — fix the root cause.

RULE 4 — CONSISTENT HELPER PATTERNS:
  If db.php uses a singleton class (e.g. "class Database"):
    → All files call Database::getInstance()->query() or Database::fetchAll() etc.
    → NEVER call getDB(), getConnection(), connectDB(), $db->query() in other files
  If db.php creates a $pdo variable:
    → All files use global $pdo; or require_once db.php first
    → NEVER call Database:: methods if no Database class exists
  Pick ONE pattern at the start and use it EVERYWHERE. No mixing.

═══ VISUAL VERIFICATION — HTTP 200 IS NOT ENOUGH ═══
🚨 A site that returns HTTP 200 CAN STILL BE A BLANK WHITE PAGE OR BROKEN CSS 🚨

After writing CSS and HTML files you MUST verify appearance:

Step 1 — CSS file exists and has real content:
  ls -la /var/www/<project>/assets/css/style.css  (must be > 5KB for a real stylesheet)
  wc -l /var/www/<project>/assets/css/style.css   (must be > 100 lines for real CSS)

Step 2 — PHP renders without fatal errors:
  php -f /var/www/<project>/index.php 2>&1 | head -30
  Output must have <html> and <body> content, not a PHP error message.

Step 3 — Browser screenshot REQUIRED before action="done":
  Use action="browse" with navigate + screenshot to see the actual rendered page.
  {"type":"navigate","url":"http://<SERVER_IP>/"},{"type":"screenshot","label":"Homepage"}
  ❌ NEVER describe the site as "looking good" or "styled correctly" without a screenshot.
  ❌ NEVER tell the user to "clear cache" — that means YOU have not verified it yourself.
  ✅ If the screenshot shows a blank/unstyled page → diagnose and fix BEFORE action="done".

Step 4 — CSS loaded check (in the screenshot or via curl):
  curl -s http://<IP>/assets/css/style.css | head -5   (must return real CSS, not 403/404)
  If 403/404 → fix file permissions: chmod 644 /var/www/<project>/assets/css/style.css

BATCH SIZE LIMITS — critical, always follow:
❌ NEVER put more than 3 files in a single python3 block
❌ NEVER put a file larger than ~15KB inside a python3 block — split it across 2 blocks
❌ NEVER try to write a full 20-table SQL schema in one command — split into 2-3 parts
✅ Write files in batches of 2-3, verify each batch, then continue with the next batch
✅ For large SQL schemas: write 8-10 tables per run action using append mode
✅ After EACH batch: ls -la to confirm file sizes match expectations before continuing

SCHEMA WRITING PATTERN — for large SQL (>5 tables):
Run 1: Create schema.sql with first 8 tables (write mode 'w')
Run 2: Append next 8 tables (append mode 'a')  
Run 3: Import full schema: mysql -u USER -p'PASS' DB < /path/schema.sql 2>&1
This prevents mid-command truncation that leaves empty files on disk.

═══ BROWSER AGENT — control a real browser (for web UIs SSH cannot reach) ═══
Use action="browse" when you need to click through a web interface:
- Creating/managing MySQL databases in cPanel (cPanel web UI required)
- WordPress admin panel actions
- Any admin dashboard that requires clicking
- Verifying a live website visually

BROWSE JSON FORMAT:
{"thought":"Opening cPanel to create the database...","action":"browse","steps":[...]}

AVAILABLE STEPS:
{"type":"navigate","url":"https://..."}                            → open URL (always screenshot after)
{"type":"screenshot","label":"Label"}                              → capture screen — ALWAYS after navigate + key actions
{"type":"click","selector":"#id","label":"Describe what"}          → click element; auto-fallbacks to text match
{"type":"fill","selector":"#input","value":"text"}                 → type into a field
{"type":"select","selector":"select#id","value":"option_value"}    → choose from dropdown
{"type":"press","key":"Enter"}                                     → keyboard key (Enter, Tab, Escape …)
{"type":"wait","ms":1500}                                          → pause (max 12000ms)
{"type":"wait_for","selector":".success","timeout":10000}          → wait until element appears
{"type":"scroll","y":600}                                          → scroll down N px (use to reveal lazy elements)
{"type":"hover","selector":"#menu"}                                → hover (reveals dropdowns)
{"type":"text","label":"Page content"}                             → full page text + interactive element map (use when you need to understand layout without a screenshot)
{"type":"html","selector":".form","label":"Form HTML"}             → raw HTML of element (for debugging selectors)
{"type":"evaluate","script":"document.title","label":"Page title"} → run arbitrary JS, returns string

RULES:
- ALWAYS screenshot after navigate to see what loaded
- ALWAYS screenshot after important clicks/form submits to verify result
- If click fails → the error result includes an auto-screenshot + page text: read those to find correct selector
- For DeepSeek (Smart mode): no vision → rely on text/html/evaluate steps to read page state
- For Gemini (Fast mode) + GPT-4o (Max mode): screenshots are analyzed by the AI directly
- Up to 20 steps per browse action; chain multiple browse actions across iterations if needed

⛔ NEVER GUESS URL PATHS — this wastes steps hitting 404s and blank pages:
  WRONG: navigate to /register, /signup, /login, /dashboard — these are GUESSES
  RIGHT: read the page first, find the ACTUAL href, then navigate to it.

  HOW TO FIND THE REAL LINKS before navigating anywhere:
  {"type":"evaluate","script":"Array.from(document.querySelectorAll('a')).map(a=>a.getAttribute('href')+'  →  '+a.innerText.trim()).filter(x=>x.trim()!=='  →  ').join('\\n')","label":"All page links and hrefs"}
  
  Then use the EXACT href found — e.g. if it says "signup.php → Get Started", navigate to signup.php NOT /signup.
  
  Apply this rule for: registration page, login page, dashboard, admin panel, any page you haven't visited yet.

cPANEL LOGIN + CREATE DATABASE (example steps):
[
  {"type":"navigate","url":"https://<host>:2083"},
  {"type":"screenshot","label":"cPanel login"},
  {"type":"fill","selector":"input[name='user']","value":"<cpanel_username>"},
  {"type":"fill","selector":"input[name='pass']","value":"<cpanel_password>"},
  {"type":"click","selector":"button[type='submit']"},
  {"type":"wait","ms":2000},
  {"type":"screenshot","label":"After login"},
  {"type":"navigate","url":"https://<host>:2083/execute/Mysql/create_database?name=<dbname>"},
  {"type":"text","label":"Create DB result"}
]

CPANEL UAPI (alternative — use these SSH commands instead of browser when possible):
uapi Mysql create_database name=<db> 2>&1
uapi Mysql create_user name=<user> password='<pass>' 2>&1
uapi Mysql set_privileges_on_database user=<user> database=<db> privileges=ALL 2>&1

WORDPRESS ADMIN (example):
[
  {"type":"navigate","url":"https://<domain>/wp-admin/"},
  {"type":"screenshot","label":"WP login page"},
  {"type":"fill","selector":"#user_login","value":"<username>"},
  {"type":"fill","selector":"#user_pass","value":"<password>"},
  {"type":"click","selector":"#wp-submit"},
  {"type":"wait","ms":2000},
  {"type":"screenshot","label":"WP dashboard"}
]

SSH vs BROWSE decision:
- File edits, cron jobs, PHP fixes → use action="run" (SSH)
- cPanel DB creation, web admin UIs → use action="browse"
- Both can be combined in the same conversation turn

═══ SITE AUDIT MODE — "visit the site / check what's missing / review the live site" ═══
When the user asks you to visit a site, audit it, find what's missing, or check if it works:
DO NOT just run curl and look at raw HTML. That is not an audit.

CORRECT AUDIT WORKFLOW — use action="browse" with ALL of these steps:

Phase A — Homepage:
{"type":"navigate","url":"http://<IP_OR_DOMAIN>/"},
{"type":"screenshot","label":"Homepage"},
{"type":"text","label":"Homepage content — sections, nav links, CTAs"},

Phase B — Navigation test (follow every main nav link):
{"type":"click","selector":"nav a:nth-child(1)","label":"Nav link 1"},
{"type":"screenshot","label":"Nav link 1 page"},
{"type":"text","label":"Nav link 1 content"},
... (repeat for each nav item)

Phase C — Registration test (DO NOT GUESS THE URL):
{"type":"evaluate","script":"Array.from(document.querySelectorAll('a')).map(a=>a.getAttribute('href')+'  →  '+a.innerText.trim()).join('\\n')","label":"Find all links — get actual signup/register href"},
→ Read the output, find the signup/register link href, THEN navigate to it exactly as shown.
{"type":"screenshot","label":"Registration form"},
{"type":"text","label":"Registration form fields — get exact input name attributes"},
Fill the form using the EXACT field names/selectors found, then submit.
{"type":"screenshot","label":"After registration submit"},

Phase D — Login test (DO NOT GUESS THE URL — read the page for the login href):
{"type":"evaluate","script":"Array.from(document.querySelectorAll('a')).map(a=>a.getAttribute('href')+'  →  '+a.innerText.trim()).join('\\n')","label":"Find login href"},
{"type":"fill","selector":"input[name='email']","value":"test@example.com"},
{"type":"fill","selector":"input[name='password']","value":"<test_password>"},
{"type":"click","selector":"button[type='submit']"},
{"type":"screenshot","label":"After login attempt"},
{"type":"text","label":"Login result — dashboard or error"}

Phase E — Authenticated pages (if login worked):
{"type":"screenshot","label":"Dashboard"},
{"type":"text","label":"Dashboard content — visible features, menu items"},
Test 2-3 core user actions (e.g. create an order, submit a form, view reports)

Phase F — Error / console check (SSH):
Run action="run": tail -30 /var/log/apache2/error.log 2>/dev/null OR find error_log 2>/dev/null | xargs tail -30

AUDIT OUTPUT — your done message must include a structured gap report:
✅ Working:
• [feature] — [evidence e.g. "HTTP 200, dashboard loads, logout button visible"]

❌ Broken:
• [feature] — [what happened e.g. "login returns blank page after submit"]

⚠️ Missing (not built yet):
• [feature] — [e.g. "password reset page returns 404"]

📸 Screenshots taken: [list labels]

STATUS: VERIFIED (all core flows work) | STATUS: PARTIAL (some flows broken) | STATUS: UNVERIFIED (cannot test)

═══ BROWSER FORM GUIDE (login, registration, any web form) ═══

STEP 1 — Read the page BEFORE filling anything:
{"type":"navigate","url":"https://example.com/register.php"},
{"type":"wait","ms":2500},
{"type":"screenshot","label":"Registration page"},
{"type":"text","label":"Form fields — read names and IDs"}   ← ALWAYS do this to learn selectors

STEP 2 — Fill each field individually, one at a time:
Use the EXACT field name/id you saw in the text step.
Example for a registration form:
{"type":"fill","selector":"input[name='full_name']","value":"John Smith"},
{"type":"fill","selector":"input[name='email']","value":"user@example.com"},
{"type":"fill","selector":"input[name='password']","value":"SecretPass123"},
{"type":"fill","selector":"input[name='confirm_password']","value":"SecretPass123"},

CONFIRM PASSWORD RULE: The confirm/repeat password field MUST contain the EXACT SAME value as the password field.
Never leave confirm password blank. Always type the same password again.

STEP 3 — Take a screenshot to verify all fields are filled BEFORE submitting:
{"type":"screenshot","label":"Form filled — before submit"}

STEP 4 — Submit and verify:
{"type":"click","selector":"button[type='submit']"},
{"type":"wait","ms":3000},
{"type":"screenshot","label":"After form submit"}
Check: success message or redirect = success. Error/validation message = fix the fields and retry.

FIELD SELECTOR FALLBACK ORDER (try each until one works):
1. input[name='fieldname']     ← most reliable — use EXACT name from page text
2. #fieldname                  ← by id
3. input[placeholder*='hint']  ← by placeholder
4. getByLabel("Label text")    ← by associated label (backend handles this)

PAGE READING RULES:
- ALWAYS screenshot after navigate — never assume what a page looks like
- Use {"type":"text"} to read page content when screenshot is unclear or you need to find selectors
- Read ALL error messages after form submit — they tell you exactly what to fix

⛔ BLANK PAGE PROTOCOL — a blank or white page is ALWAYS an error condition, NEVER a success:
When any page appears blank/white/empty after a navigate or form submit:
1. {"type":"wait","ms":5000}                          — wait 5 seconds for JS to render
2. {"type":"screenshot","label":"After wait 5s"}     — re-check
3. If still blank: {"type":"wait","ms":10000}         — wait 10 more seconds
4. {"type":"navigate","url":"(same url)"}             — refresh
5. {"type":"screenshot","label":"After refresh"}
6. {"type":"text","label":"Page text after refresh"} — read all visible text
7. {"type":"evaluate","script":"document.location.href","label":"Current URL"} — check URL changed?
8. {"type":"evaluate","script":"window.onerror ? 'JS errors' : 'no JS errors'","label":"JS errors"}
9. Only THEN conclude success or failure based on evidence.
NEVER write "page is blank, action likely succeeded" — that is ALWAYS wrong.

COMMON LOGIN SELECTORS (try in order):
- User/Name: input[name='username'], input[name='user'], input[name='email'], input[name='login'], #user_login
- Password: input[name='password'], input[name='pass'], #user_pass, input[type='password']
- Confirm pw: input[name='confirm_password'], input[name='password_confirmation'], input[name='confirm'], input[name='retype_password']
- Submit: button[type='submit'], input[type='submit'], .login-submit, #wp-submit

AFTER FORM SUBMIT — verify:
- Success: redirected to dashboard/profile OR success message shown
- Failure: still on same page, error message visible — read it with text step and fix

⛔ OUTCOME VERIFICATION — the single most critical rule in this system:

A blank page, white screen, about:blank, navigation timeout, loading spinner,
empty DOM, or unreadable content is NEVER evidence of success.
It is ALWAYS evidence of UNKNOWN STATE.

When outcome is unknown:
1. Mark state as UNKNOWN in your thought — never assume success
2. {"type":"wait","ms":5000}                          — wait for JS to render
3. {"type":"screenshot","label":"After wait"}        — re-check visually
4. {"type":"navigate","url":"(same url)"}             — refresh
5. {"type":"text","label":"Page text after refresh"} — read all visible text
6. {"type":"evaluate","script":"document.location.href","label":"Current URL"}
7. Look for: login state, dashboard, logout button, success message, user data
8. If still cannot verify → output STATUS: UNVERIFIED in done message
NEVER write "status unknown, action likely succeeded" — that is always logically wrong.

EVIDENCE OF SUCCESS — must include at least ONE of these:
✅ Success/confirmation message explicitly visible on page
✅ Dashboard or authenticated page loaded (not a login/signup form)
✅ Logout button / account menu / username visible in header
✅ Account data, balance, or profile info visible
✅ Order ID or transaction reference shown on screen
✅ URL has changed to the expected post-action destination
❌ "Page appeared to submit" — NOT evidence
❌ "Redirect probably worked" — NOT evidence
❌ "Registration likely succeeded" — NOT evidence
❌ Blank page after click — NEVER evidence of anything except UNKNOWN STATE

10 VERIFICATION RULES — apply these to every browser action:
1. Never claim success without evidence (see EVIDENCE OF SUCCESS list above)
2. If page shows "Sign In", "Login", "Register", or "Create Account" → user is NOT authenticated
3. Blank/white page after form submit = UNKNOWN STATE → apply recovery protocol above
4. For REGISTRATION: verify by navigating to login page and successfully logging in with the new credentials
5. For LOGIN: verify by checking for logout button / dashboard URL / username in header
6. For PAYMENT/DEPOSIT: read balance BEFORE action, then AFTER — must show a change to claim success
7. For ORDERS: confirm order ID or order history entry exists before claiming order was placed
8. For FILE UPLOAD/SAVE: reload the page and confirm data is still visible
9. Before action="done": compare your written conclusion against the last screenshot — if they contradict each other, investigate before finishing
10. If verification cannot be completed → output STATUS: UNVERIFIED (never STATUS: COMPLETED for unverified work)

After REGISTRATION:
  Goal = account exists and can authenticate
  Verify: navigate to login page → fill new credentials → submit → check dashboard loads
  NOT: "I clicked Create Account" → assume "registration likely succeeded"

After LOGIN:
  Goal = authenticated session is active
  Verify: look for logout button / account menu / dashboard URL / username visible in page
  {"type":"evaluate","script":"document.querySelector('.logout,[href*=logout],[href*=signout]')?.innerText","label":"Logout link"}
  Logout link or dashboard URL present → login confirmed. Otherwise → session failed, retry.

After PAYMENT / DEPOSIT:
  Goal = payment request created with a verifiable reference
  Verify: transaction ID visible OR "pending" status OR payment confirmation message with amount
  NEVER report deposit success if no transaction reference was shown.
  {"type":"text","label":"Payment confirmation"} → look for order/ref/transaction number
  Read balance BEFORE and AFTER — amount must change.

After FILE UPLOAD / FORM SAVE:
  Goal = data persisted to storage
  Verify: reload the page → confirm data is still there
  {"type":"navigate","url":"(same page)"}
  {"type":"text","label":"Data after reload"} → confirm values are present`;


};

router.post("/:id/chat", async (req, res) => {
  const schema = z.object({
    messages: z.array(z.object({
      role:    z.enum(["user", "assistant"]),
      content: z.string().max(20000),
    })).min(1).max(60),
    mode: z.enum(["economy", "balanced", "high-power", "kimi", "v4pro", "auto"]).default("high-power"),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });

  const [s] = await db.select().from(serversTable).where(eq(serversTable.id, parseInt(req.params.id)));
  if (!s) return res.status(404).json({ error: "Not found" });

  res.setHeader("Content-Type",  "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("X-Accel-Buffering", "no");

  const send = (type: string, payload: Record<string, unknown>) =>
    res.write(`data: ${JSON.stringify({ type, ...payload })}\n\n`);

  const modelMap: Record<string, { provider: "openrouter" | "deepseek" | "openai" | "nvidia"; model: string }> = {
    "economy":    { provider: "openrouter", model: "google/gemini-2.0-flash-001" },
    "balanced":   { provider: "deepseek",   model: "deepseek-chat" },
    "high-power": { provider: "openai",     model: "gpt-4o" },
    "kimi":       { provider: "nvidia",     model: "moonshotai/kimi-k2.6" },
    "v4pro":      { provider: "nvidia",     model: "deepseek-ai/deepseek-v4-pro" },
    "auto":       { provider: "nvidia",     model: "moonshotai/kimi-k2.6" }, // starts as planner; rotates per loop
  };

  const ssh = async (cmd: string): Promise<{ out: string; code: number }> => {
    try {
      const r = await sshExec(s.host, s.port, s.username, s.authType ?? "key", s.privateKey, s.password, cmd);
      return { out: (r.stdout + (r.stderr ? `\n[stderr] ${r.stderr}` : "")).trim(), code: r.code };
    } catch (e: unknown) {
      return { out: `SSH error: ${e instanceof Error ? e.message : String(e)}`, code: -1 };
    }
  };

  const parseAgentJSON = (raw: string) => {
    // Strip DeepSeek DSML tool-call blocks — DeepSeek-V3 sometimes outputs its own
    // function-call syntax using full-width Unicode pipes ｜｜ (U+FF5C), not ASCII |.
    // Pattern: <｜｜DSML｜｜invoke ...> or <｜｜DSML｜｜tool_calls> (with any pipe variant)
    // Strategy: if "DSML" appears anywhere in the response, extract only the JSON
    // object that appears BEFORE the first DSML tag — everything after is discarded.
    // Detect DeepSeek DSML bleed — the string "DSML" only appears in their
    // internal tool-call syntax, never in valid JSON. If we see it anywhere,
    // keep only what came before that point (the model may have prefixed a
    // JSON object before the DSML block). If the block starts at position 0
    // the whole response is DSML and we return nothing usable.
    let cleaned = raw;
    const dsmlIdx = raw.indexOf("DSML");
    if (dsmlIdx === 0) {
      cleaned = "";
    } else if (dsmlIdx > 0) {
      // Walk back to the nearest '<' or '｜' before "DSML" to drop the tag start
      let cut = dsmlIdx;
      while (cut > 0 && !"<｜|".includes(raw[cut - 1]!)) cut--;
      cleaned = raw.slice(0, Math.max(0, cut - 1)).trim();
    }
    const stripped = cleaned.replace(/^```(?:json)?\s*/i, "").replace(/\s*```\s*$/, "").trim();
    try { return JSON.parse(stripped); } catch { /* try extraction */ }
    const m = stripped.match(/\{[\s\S]*\}/);
    if (m) try { return JSON.parse(m[0]); } catch { /* fall through */ }
    return null;
  };

  try {
    const { provider: baseProvider, model: baseModel } = modelMap[parsed.data.mode];
    const isAuto = parsed.data.mode === "auto";
    const systemPrompt = CHAT_AGENT_SYSTEM(s.username, parsed.data.messages.length, s.githubToken);

    type AIContent = string | Array<{ type: "text"; text: string } | { type: "image_url"; image_url: { url: string; detail?: string } }>;
    // Build AI conversation — content can be string or multimodal array (for vision/screenshots)
    const aiMessages: { role: "system" | "user" | "assistant"; content: AIContent }[] = [
      { role: "system", content: systemPrompt },
      ...parsed.data.messages.map(m => ({ role: m.role as "user" | "assistant", content: m.content })),
    ];

    // Token + time tracking across all iterations
    let totalPromptTokens     = 0;
    let totalCompletionTokens = 0;
    let totalIterations       = 0;
    let doneAttempts          = 0;  // times we've pushed back on unverified done
    const startTime = Date.now();

    // Guard: flushTokens must only fire ONCE per request — prevents double-emit when both
    // a done/reply handler and the post-loop fallback both try to flush.
    let tokensFlushed = false;
    const flushTokens = async (summary?: string) => {
      if (tokensFlushed) return;
      tokensFlushed = true;
      const durationMs = Date.now() - startTime;
      const total = totalPromptTokens + totalCompletionTokens;
      const reportModel = isAuto ? "auto (Kimi→V4Pro→V4Flash)" : baseModel;
      send("tokens", {
        prompt: totalPromptTokens, completion: totalCompletionTokens,
        total, iters: totalIterations, model: reportModel, durationMs,
      });
      // Persist to history DB
      const userTask = parsed.data.messages[parsed.data.messages.length - 1]?.content?.slice(0, 1000) ?? "";
      await db.insert(serverTaskHistoryTable).values({
        serverId: s.id, task: userTask, summary: summary?.slice(0, 2000) ?? "",
        model: reportModel, promptTokens: totalPromptTokens, completionTokens: totalCompletionTokens,
        totalTokens: total, iterations: totalIterations, durationMs,
      }).catch(() => {});
    };

    // Track commands run this session to detect infinite loops
    const cmdRunCount = new Map<string, number>();
    // For auto mode: track current agent role
    let currentRole: AgentRole = "planner";
    // Track consecutive all-fail command batches to trigger auto-replan
    let consecutiveFailBatches = 0;
    // Phase-boundary fresh context: track last checkpoint phase seen
    let lastCheckpointPhase = 0;
    // Capture original user task (index 1 in aiMessages after system prompt) for fresh context resets
    const originalUserMessage = parsed.data.messages[parsed.data.messages.length - 1]?.content ?? "";
    const homeDir = s.username === "root" ? "/root" : `/home/${s.username}`;

    // Agentic loop — max 80 iterations per user turn (large project builds need many steps)
    for (let iter = 0; iter < 80; iter++) {
      // ── Auto mode: role rotation ───────────────────────────────────────────
      // iter 0 → Kimi K2.6 (planner: breaks down task)
      // iter 1+ → DeepSeek V4 Pro (builder: writes code, runs commands)
      // loop detected → GLM 5.1 (recovery: new approach)
      // (verifier role is used as a quick post-command check, not the main loop model)
      let iterModel = baseModel;
      let iterClient = getAIClient(baseProvider);
      if (isAuto) {
        const prevRole: AgentRole = currentRole;
        if (iter === 0) currentRole = "planner";
        else if (currentRole === "recovery") { /* keep recovery until unstuck */ }
        else currentRole = "builder";
        iterModel  = autoModel(currentRole);
        iterClient = getAIClient(autoProvider(currentRole));
        // Only announce role when it changes (don't repeat "Planning…" on every iter)
        if (currentRole !== prevRole || iter === 0) {
          const roleLabel: Record<AgentRole, string> = {
            planner:  "Planning…",
            builder:  "Building…",
            verifier: "Verifying…",
            recovery: "Recovering…",
          };
          send("think", { text: roleLabel[currentRole] ?? "Thinking…" });
        }
      }

      // ── Context compression — prevent context window overflow on long builds ──
      // After many iterations, aiMessages grows huge (150K+ chars). Compress old turns
      // into a digest so the model always has room to reason about the current step.
      if (iter > 0 && iter % 10 === 0) {
        // Measure total chars excluding system prompt (index 0)
        const bodyChars = aiMessages.slice(1).reduce((sum, m) =>
          sum + (typeof m.content === "string" ? m.content.length : JSON.stringify(m.content).length), 0);
        if (bodyChars > 80000) {
          // Keep: system prompt + first user message + compressed digest + last 6 messages
          const firstUserMsg  = aiMessages[1];                          // original user task
          const droppedCount  = aiMessages.length - 8;
          const homeDir       = s.username === "root" ? "/root" : `/home/${s.username}`;
          const digestMsg = {
            role: "user" as const,
            content:
              `[CONTEXT COMPRESSED — ${droppedCount} earlier message pairs omitted to fit context window]\n` +
              `You are mid-task on server ${s.host} as ${s.username}. The task is still in progress — keep building.\n` +
              `To recall phase state: cat ${homeDir}/.xd_checkpoint.json 2>/dev/null\n` +
              `To recall workspace: cat ${homeDir}/.xd_workspace.json 2>/dev/null\n` +
              `Continue exactly where you left off. Do NOT restart or repeat already-completed phases.`,
          };
          aiMessages.splice(1, aiMessages.length - 7, firstUserMsg, digestMsg);
          send("think", { text: `Context compressed at iter ${iter} (${Math.round(bodyChars / 1000)}K chars → trimmed to last 6 messages)` });
        }
      }

      // ── Retry with backoff on 429 rate-limit ───────────────────────────────
      const callWithRetry = async () => {
        const delays = [8000, 20000, 40000]; // 8s → 20s → 40s
        for (let attempt = 0; attempt <= delays.length; attempt++) {
          try {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            return await iterClient.chat.completions.create({
              model: iterModel,
              messages: aiMessages as any[],
              max_tokens: 8192,
              temperature: iter === 0 ? 0.3 : 0.1,
            });
          } catch (err: unknown) {
            const status = (err as { status?: number })?.status;
            const msg    = String((err as { message?: string })?.message ?? err);
            const is429  = status === 429 || msg.includes("429") || msg.toLowerCase().includes("rate limit");
            if (!is429 || attempt >= delays.length) throw err;
            const wait = delays[attempt];
            send("think", { text: `Rate limit — retrying in ${wait / 1000}s…` });
            await new Promise(r => setTimeout(r, wait));
          }
        }
        throw new Error("Unreachable");
      };
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const completion = await callWithRetry() as any;

      // Accumulate tokens
      if (completion.usage) {
        totalPromptTokens     += completion.usage.prompt_tokens     ?? 0;
        totalCompletionTokens += completion.usage.completion_tokens ?? 0;
      }
      totalIterations++;

      const raw = completion.choices[0]?.message?.content ?? "";
      const action = parseAgentJSON(raw);

      if (!action) {
        if (raw.includes("DSML")) {
          // DeepSeek leaked its internal tool-call syntax instead of JSON.
          // Auto mode: hand off to GLM 5.1 (recovery) to regenerate the step cleanly.
          // Limit to 2 DSML recovery attempts to avoid loops.
          const dsmlRetries = (aiMessages.filter(m => m.role === "user" && typeof m.content === "string" && m.content.includes("DSML_RECOVERY")).length);
          if (isAuto && dsmlRetries < 2) {
            currentRole = "recovery";
            iterModel  = autoModel("recovery");
            iterClient = getAIClient(autoProvider("recovery"));
            send("think", { text: "Recovering from DSML format error — switching to GLM…" });
            aiMessages.push({ role: "assistant", content: raw });
            aiMessages.push({
              role: "user",
              content: [
                "DSML_RECOVERY: The previous model (DeepSeek) output its internal tool-call format (DSML) instead of",
                "the required JSON response. Your job is to regenerate the response in the correct format.",
                "",
                "Produce ONLY a single valid JSON object matching this schema:",
                '{"thought":"...","action":"run","commands":[{"cmd":"...","desc":"..."}]}',
                "or action=browse/done/reply as appropriate. NO DSML syntax. NO tool_calls blocks. Pure JSON only.",
                "",
                "Continue the task from where it was — do not restart, do not repeat completed work.",
              ].join("\n"),
            });
            continue;
          }
          // GLM also failed or non-auto mode — surface the error
          send("reply", { text: "⚠️ The AI model produced an invalid internal format (DSML). GLM recovery also failed — please try again." });
        } else {
          // Plain text (not JSON) — treat as a reply
          send("reply", { text: raw || "Unexpected response from AI." });
        }
        break;
      }

      // Always stream the thought
      if (action.thought) send("think", { text: action.thought });

      if (action.action === "run" && Array.isArray(action.commands) && action.commands.length) {
        const cmds: { cmd: string; desc: string }[] = action.commands
          .filter((c: unknown) => c && typeof (c as Record<string,unknown>).cmd === "string")
          .slice(0, 10);

        // ── Loop detection ──────────────────────────────────────────────────────
        // Normalise command (strip extra whitespace) so minor variations still match
        const normCmd = (c: string) => c.replace(/\s+/g, " ").trim();
        const repeatCmds = cmds.filter(c => (cmdRunCount.get(normCmd(c.cmd)) ?? 0) >= 1);
        const allRepeats = repeatCmds.length === cmds.length;

        if (allRepeats && cmds.length > 0) {
          // Every command in this batch has already been run — agent is looping
          // In auto mode: escalate to GLM 5.1 (recovery specialist) for next iteration
          if (isAuto && currentRole !== "recovery") {
            currentRole = "recovery";
            send("think", { text: "Recovering…" });
          }
          const loopWarning =
            `⚠️ LOOP DETECTED: Every command in this batch has already been run this session:\n` +
            cmds.map(c => `  • ${normCmd(c.cmd)} (run ${cmdRunCount.get(normCmd(c.cmd))}x)`).join("\n") + `\n\n` +
            `You are stuck in a loop. STOP running the same commands. Instead:\n` +
            `1. Look at what the previous outputs actually said — the answer is already in your context.\n` +
            `2. Try a COMPLETELY DIFFERENT approach or command.\n` +
            `3. If you genuinely cannot proceed, use action="done" and report what you found so far.\n` +
            `DO NOT repeat these commands again.`;
          send("think", { text: "⚠️ Loop detected — all commands already run. Forcing course correction." });
          aiMessages.push({ role: "assistant", content: raw });
          aiMessages.push({ role: "user", content: loopWarning });
          continue;
        } else if (repeatCmds.length > 0) {
          // Some commands repeated — warn but still run the new ones
          const warnText = `Note: These commands were already run: ${repeatCmds.map(c => normCmd(c.cmd)).join("; ")}. Their output is already in your context — re-reading it won't give new information. Focus on NEW commands to make progress.`;
          aiMessages.push({ role: "user", content: warnText });
        }

        // Record all commands as run
        for (const c of cmds) cmdRunCount.set(normCmd(c.cmd), (cmdRunCount.get(normCmd(c.cmd)) ?? 0) + 1);

        const cmdResults: string[] = [];

        for (let ci = 0; ci < cmds.length; ci++) {
          const { cmd, desc } = cmds[ci];
          send("cmd_start", { index: ci, total: cmds.length, cmd, desc });

          const result = await sshExec(
            s.host, s.port, s.username, s.authType ?? "key",
            s.privateKey, s.password, cmd,
            (chunk) => send("cmd_output", { index: ci, chunk }),
          ).catch((e: unknown) => ({
            stdout: "",
            stderr: String(e instanceof Error ? e.message : e),
            code: -1,
          }));

          send("cmd_done", { index: ci, code: result.code });

          // Build output for AI context — stderr always included so AI sees errors
          const rawOut = [
            result.stdout.trim(),
            result.stderr.trim() ? `[stderr] ${result.stderr.trim()}` : "",
          ].filter(Boolean).join("\n") || "(no output)";

          // Trim long outputs to prevent context explosion — keep tail (errors show at end)
          const trimLines = (s: string, max = 60): string => {
            const lines = s.split("\n");
            if (lines.length <= max) return s;
            const kept = lines.slice(-max);
            return `[...${lines.length - max} lines omitted...]\n${kept.join("\n")}`;
          };
          const out = trimLines(rawOut);

          cmdResults.push(`$ ${cmd}\n${out}\n[exit ${result.code}]`);
        }

        // Feed full results back into AI context — critical for next iteration
        const resultText = cmdResults.join("\n\n─────\n\n");
        aiMessages.push({ role: "assistant", content: raw });

        // ── Consecutive-failure tracking → auto-replan via Kimi ────────────────
        // If every command in this batch failed (non-zero exit), track it.
        // After 2 consecutive all-fail batches, switch to Kimi to replan the
        // workspace checkpoint, then resume building with the worker model.
        const allFailed = cmds.length > 0 && cmdResults.every(r => /\[exit [^0]/.test(r));
        const anySucceeded = cmdResults.some(r => /\[exit 0\]/.test(r));
        if (anySucceeded) {
          consecutiveFailBatches = 0;
        } else if (allFailed) {
          consecutiveFailBatches++;
        }

        // ── Phase-boundary fresh context reset ────────────────────────────────
        // When the agent writes a checkpoint with an advanced phase number,
        // wipe the accumulated SSH output (which balloons to 30K+ tokens) and
        // restart with a clean context so the next phase doesn't carry baggage.
        const checkpointWriteCmd = cmds.find(c =>
          c.cmd.includes("xd_checkpoint.json") && (c.cmd.includes(">") || c.cmd.includes("tee"))
        );
        if (checkpointWriteCmd) {
          // Extract the phase number from the checkpoint write command
          const phaseMatch = checkpointWriteCmd.cmd.match(/"phase"\s*:\s*(\d+)/);
          const newPhase = phaseMatch ? parseInt(phaseMatch[1]) : 0;
          if (newPhase > lastCheckpointPhase) {
            lastCheckpointPhase = newPhase;
            // Only reset if we've accumulated significant context (> 3 message pairs)
            if (aiMessages.length > 6) {
              send("think", { text: `✅ Phase ${newPhase - 1} complete — fresh context for Phase ${newPhase} (clearing ${aiMessages.length - 2} accumulated messages)` });
              // FRESH CONTEXT RESET: keep only system prompt + inject clean phase start
              const freshStart = {
                role: "user" as const,
                content:
                  `PHASE ${newPhase} — FRESH CONTEXT START\n` +
                  `Previous phases complete. Context reset to prevent token overflow.\n\n` +
                  `Your original task:\n${originalUserMessage.slice(0, 800)}${originalUserMessage.length > 800 ? "\n[...see spec file for full details]" : ""}\n\n` +
                  `Run these two commands FIRST to restore state:\n` +
                  `  cat ${homeDir}/.xd_checkpoint.json 2>/dev/null\n` +
                  `  cat ${homeDir}/.xd_spec.txt 2>/dev/null | head -50\n\n` +
                  `Then IMMEDIATELY continue building Phase ${newPhase}. ` +
                  `Do NOT repeat work from completed phases. Do NOT re-plan from scratch.`,
              };
              // Wipe all accumulated messages, start clean
              aiMessages.splice(1, aiMessages.length - 1, freshStart);
              // Reset loop detection — new phase, new commands
              cmdRunCount.clear();
              consecutiveFailBatches = 0;
              // Switch back to builder for the new phase
              if (isAuto && currentRole !== "planner") currentRole = "builder";
            }
            continue; // immediately start next iteration with fresh context
          }
        }

        if (isAuto && consecutiveFailBatches >= 2) {
          consecutiveFailBatches = 0;
          // Switch to Kimi planner to replan based on current failures
          currentRole = "planner";
          send("think", { text: "⚠️ Repeated failures — switching to Kimi to replan strategy…" });
          aiMessages.push({
            role: "user",
            content:
              `⚠️ REPLAN REQUIRED — the last 2 command batches all failed.\n\n` +
              `FAILED COMMAND RESULTS:\n${resultText}\n\n` +
              `Your job as PLANNER:\n` +
              `1. Read the checkpoint: cat ${homeDir}/.xd_checkpoint.json 2>/dev/null\n` +
              `2. Identify the root cause of the repeated failures from the output above\n` +
              `3. Output a REVISED plan — different approach, different commands, different file paths\n` +
              `4. Update the checkpoint with the new plan:\n` +
              `   echo '{"phase":N,"done":[...],"next":"revised approach: ...","failed_approach":"what was tried"}' > ${homeDir}/.xd_checkpoint.json\n\n` +
              `Then use action="run" with the FIRST command of the new approach.\n` +
              `DO NOT repeat the same commands that just failed.`,
          });
          // Next iteration will use Kimi (planner) via currentRole; after that, builder resumes
        } else {
          aiMessages.push({
            role: "user",
            content: `COMMAND RESULTS (read carefully before deciding next step):\n\n${resultText}\n\n` +
                     `Now CONTINUE the task. Do NOT ask the user — search, read, and fix autonomously.`,
          });
        }

        // Also stream results summary so frontend can add to history
        send("cmd_results", { text: resultText });

      } else if (action.action === "browse" && Array.isArray(action.steps) && action.steps.length) {
        const steps = (action.steps as BrowserStep[]).slice(0, 20);
        const browseLog: string[] = [];
        // Separate queues: text context (always) vs screenshots (sent to Nemotron VL)
        const textParts: string[] = [];
        const screenshotsForVision: Array<{ label: string; b64: string }> = [];
        let shotCount = 0;

        send("browser_start", { stepCount: steps.length });

        await runBrowserSteps(steps, (result) => {
          if (result.screenshot) {
            shotCount++;
            const label = result.label ?? `Screenshot ${shotCount}`;
            send("browser_shot", { index: result.index, label, data: result.screenshot });
            // Queue screenshot for Nemotron VL vision analysis (max 5)
            if (shotCount <= 5) {
              screenshotsForVision.push({ label, b64: result.screenshot });
            }
            browseLog.push(`step ${result.index}: screenshot — ${label}`);
          } else if (result.text) {
            const snippet = result.text.slice(0, 800);
            browseLog.push(`step ${result.index}: page text — ${snippet}`);
            textParts.push(`Page text: ${snippet}`);
            send("browser_text", { index: result.index, text: snippet });
          } else if (!result.ok) {
            browseLog.push(`step ${result.index}: ${result.type} FAILED — ${result.error}`);
            if (result.screenshot) {
              shotCount++;
              const label = `Error state (step ${result.index}: ${result.type})`;
              send("browser_shot", { index: result.index, label, data: result.screenshot });
              if (shotCount <= 5) screenshotsForVision.push({ label, b64: result.screenshot });
            }
            if (result.text) {
              browseLog.push(`  page text on failure: ${result.text.slice(0, 400)}`);
              textParts.push(`Page state on failure: ${result.text.slice(0, 800)}`);
            }
            send("browser_err", { index: result.index, type: result.type, error: result.error });
          } else {
            browseLog.push(`step ${result.index}: ${result.type} OK${result.label ? ` (${result.label})` : ""}`);
          }
        });

        const resultSummary = browseLog.join("\n");
        send("browser_done", { stepsDone: steps.length });

        // ── Screenshot Vision Pipeline ──────────────────────────────────────────
        // Primary:  Gemini 2.0 Flash (REST API, GEMINI_API_KEY) — best accuracy
        // Fallback: Nemotron VL via NVIDIA NIM (nvidia/nemotron-nano-12b-v2-vl)
        // DeepSeek / GLM / Kimi MUST NOT receive image_url — they crash with 400.
        const visionDescriptions: string[] = [];
        if (screenshotsForVision.length > 0) {
          // Run all screenshots in parallel for speed
          const analyses = await Promise.all(
            screenshotsForVision.map(async (shot) => {
              send("think", { text: `Analyzing screenshot: ${shot.label}…` });

              // 1️⃣ Try Gemini 2.0 Flash first
              const geminiResult = await analyzeScreenshotWithGemini(shot.b64, shot.label);
              if (!geminiResult.startsWith("[Gemini")) {
                return `[Vision: ${shot.label}]\n${geminiResult}`;
              }

              // 2️⃣ Gemini unavailable — fall back to Nemotron VL
              try {
                const nvClient = getAIClient("nvidia");
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                const vResp = await (nvClient.chat.completions.create as any)({
                  model: "nvidia/nemotron-nano-12b-v2-vl",
                  messages: [{
                    role: "user",
                    content: [
                      { type: "text", text: 'Analyze this screenshot. Return ONLY JSON:\n{"page_type":"","visible_errors":[],"missing_elements":[],"css_loaded":true,"page_blank":false,"next_action":"","confidence":0.9}' },
                      { type: "image_url", image_url: { url: `data:image/jpeg;base64,${shot.b64}` } },
                    ],
                  }],
                  max_tokens: 512,
                  temperature: 0.1,
                });
                const desc = vResp.choices?.[0]?.message?.content ?? "analysis unavailable";
                return `[Vision (Nemotron fallback): ${shot.label}]\n${desc}`;
              } catch (e) {
                return `[Vision failed: ${shot.label}] Gemini: ${geminiResult} | Nemotron: ${String(e).slice(0, 150)}`;
              }
            })
          );
          visionDescriptions.push(...analyses);
        }

        // Combine: step log + page text + vision analysis descriptions
        const fullBrowserContext = [
          `BROWSER RESULTS (${steps.length} steps done):`,
          resultSummary,
          ...(textParts.length ? ["\nPAGE TEXT:", ...textParts] : []),
          ...(visionDescriptions.length ? ["\nSCREENSHOT ANALYSIS (from Nemotron VL):", ...visionDescriptions] : []),
          "\nBased on the above, decide next steps and continue autonomously.",
        ].join("\n");

        aiMessages.push({ role: "assistant", content: raw });
        aiMessages.push({ role: "user", content: fullBrowserContext });

      } else if (action.action === "reply") {
        await flushTokens(action.message);
        send("reply", { text: action.message ?? "I need more information." });
        break;

      } else if (action.action === "done") {
        // Done guard: block unverified done on any build/fix/site task.
        // Allows up to 3 pushbacks; on the 4th attempt we accept to avoid infinite loop.
        const userTask = (parsed.data.messages[parsed.data.messages.length - 1]?.content ?? "").toLowerCase();
        const isComplexTask = /build|rebuild|fix|deploy|install|setup|creat|redesign|payment|api|site|connect|implement|develop|add|update/i.test(userTask);
        const doneMsg = (action.message ?? "").toLowerCase();

        // Verified = agent ran HTTP checks and found them passing.
        // Screenshot is a bonus — curl 200 + content grep is sufficient on its own.
        // STATUS: UNVERIFIED is also accepted (agent was honest about failure to verify).
        const hasVerification = (
          /status:\s*verified/i.test(doneMsg) ||
          /status:\s*unverified/i.test(doneMsg) ||           // agent was honest, accept it
          /http[:\s]+200/i.test(doneMsg) ||                  // any HTTP 200 mention
          /curl.*20[0-9]/i.test(doneMsg) ||                  // any curl 2xx
          /grep.*[1-9]\d*|[1-9]\d*.*grep/i.test(doneMsg)    // content grep returned > 0
        );

        if (isComplexTask && !hasVerification && doneAttempts < 3) {
          doneAttempts++;
          send("think", { text: `⚠️ No HTTP check shown (attempt ${doneAttempts}/3) — requesting curl verification…` });
          aiMessages.push({ role: "assistant", content: raw });
          aiMessages.push({
            role: "user",
            content:
              `⛔ VERIFICATION NEEDED — show that the site is reachable before done.\n\n` +
              `Run these TWO checks (screenshot is optional):\n\n` +
              `1. HTTP status:\n` +
              `   curl -s -o /dev/null -w "HTTP %{http_code}" "http://<IP-or-domain>/" 2>/dev/null\n\n` +
              `2. Content check (must return > 0):\n` +
              `   curl -s "http://<IP-or-domain>/" | grep -c '<section\\|<main\\|hero\\|content\\|container'\n\n` +
              `If both pass → emit done with STATUS: VERIFIED.\n` +
              `If the site is unreachable for a known reason (e.g. domain not propagated) → emit done with STATUS: UNVERIFIED and explain why.\n` +
              `Do NOT keep looping if the site is working — curl is the ground truth.`,
          });
          continue;
        }

        await flushTokens(action.message);
        send("done", { text: action.message ?? "Task completed." });
        break;

      } else {
        await flushTokens(action.message ?? raw);
        send("reply", { text: action.message ?? raw });
        break;
      }
    }

    // If loop exhausted without done/reply — flush tokens anyway
    await flushTokens("Max iterations reached").catch(() => {});

    res.end();
  } catch (err: unknown) {
    send("error", { text: String(err instanceof Error ? err.message : err) });
    res.end();
  }
});

// ─── ZIP File Upload → extract + send to AI ──────────────────────────────────

router.post("/:id/upload", upload.single("file"), async (req, res) => {
  const [s] = await db.select().from(serversTable).where(eq(serversTable.id, parseInt(req.params.id as string)));
  if (!s) return res.status(404).json({ error: "Not found" });
  if (!req.file) return res.status(400).json({ error: "No file uploaded" });

  const ext = path.extname(req.file.originalname).toLowerCase();
  if (ext !== ".zip") return res.status(400).json({ error: "Only .zip files are supported" });

  try {
    const zip = new AdmZip(req.file.buffer);
    const entries = zip.getEntries();

    const TEXT_EXTS = new Set([".php", ".html", ".htm", ".css", ".js", ".ts", ".json", ".sql", ".txt", ".md", ".env", ".htaccess", ".xml", ".yaml", ".yml"]);
    const IMAGE_EXTS = new Set([".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".ico"]);

    const files: { path: string; content: string; size: number; isImage?: boolean }[] = [];
    let totalText = 0;

    for (const entry of entries) {
      if (entry.isDirectory) continue;
      const entryPath = entry.entryName;
      const entryExt = path.extname(entryPath).toLowerCase();
      const size = entry.header.size;

      if (IMAGE_EXTS.has(entryExt)) {
        files.push({ path: entryPath, content: "[image file]", size, isImage: true });
        continue;
      }

      if (TEXT_EXTS.has(entryExt) || entryExt === "") {
        if (totalText < 80000) {
          try {
            const content = entry.getData().toString("utf8").slice(0, 8000);
            files.push({ path: entryPath, content, size });
            totalText += content.length;
          } catch { files.push({ path: entryPath, content: "[binary file]", size }); }
        } else {
          files.push({ path: entryPath, content: "[content truncated — too many files]", size });
        }
      } else {
        files.push({ path: entryPath, content: "[binary file]", size });
      }
    }

    return res.json({
      zipName: req.file.originalname,
      fileCount: files.length,
      files,
    });
  } catch (err: unknown) {
    return res.status(500).json({ error: `Failed to read zip: ${err instanceof Error ? err.message : String(err)}` });
  }
});

// ─── Task History ─────────────────────────────────────────────────────────────

// ─── SFTP File Download ───────────────────────────────────────────────────────

router.get("/:id/sftp-download", async (req, res) => {
  const remotePath = (req.query.path as string) ?? "";
  if (!remotePath) return res.status(400).json({ error: "path query param required" });

  const [s] = await db.select().from(serversTable).where(eq(serversTable.id, parseInt(req.params.id)));
  if (!s) return res.status(404).json({ error: "Not found" });

  const client = new Client();
  const filename = remotePath.split("/").pop() ?? "download";

  client.on("ready", () => {
    client.sftp((err, sftp) => {
      if (err) { client.end(); if (!res.headersSent) res.status(500).json({ error: err.message }); return; }

      sftp.stat(remotePath, (statErr, stat) => {
        if (statErr) {
          client.end();
          if (!res.headersSent) res.status(404).json({ error: `File not found on server: ${remotePath}` });
          return;
        }
        res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
        res.setHeader("Content-Type", "application/octet-stream");
        res.setHeader("Content-Length", stat.size);

        const stream = sftp.createReadStream(remotePath);
        stream.on("error", () => { client.end(); });
        stream.on("end",   () => { client.end(); });
        stream.pipe(res);
      });
    });
  });

  client.on("error", (err) => {
    if (!res.headersSent) res.status(500).json({ error: err.message });
  });

  const connectOpts: Record<string, unknown> = {
    host: s.host, port: s.port, username: s.username, readyTimeout: 30000,
  };
  if (s.authType === "key" && s.privateKey) connectOpts["privateKey"] = s.privateKey;
  else if (s.password) connectOpts["password"] = s.password;
  client.connect(connectOpts as Parameters<Client["connect"]>[0]);
});

router.get("/:id/history", async (req, res) => {
  const [s] = await db.select().from(serversTable).where(eq(serversTable.id, parseInt(req.params.id)));
  if (!s) return res.status(404).json({ error: "Not found" });
  const rows = await db.select().from(serverTaskHistoryTable)
    .where(eq(serverTaskHistoryTable.serverId, s.id))
    .orderBy(serverTaskHistoryTable.id)
    .limit(50);
  return res.json(rows.reverse());
});

// ─── Metrics ─────────────────────────────────────────────────────────────────

router.get("/:id/metrics", async (req, res) => {
  const [s] = await db.select().from(serversTable).where(eq(serversTable.id, parseInt(req.params.id)));
  if (!s) return res.status(404).json({ error: "Not found" });

  if (s.status !== "online") {
    return res.json({ cpu: 0, ram: 0, storage: 0, network: 0, uptime: 0, status: s.status });
  }

  try {
    const { stdout } = await sshExec(
      s.host, s.port, s.username, s.authType ?? "key",
      s.privateKey, s.password,
      `echo CPU:$(top -bn1 | grep 'Cpu(s)' | awk '{print $2}' | tr -d '%us,') MEM:$(free | awk '/Mem:/{printf "%.0f", $3/$2*100}') DISK:$(df / | awk 'NR==2{print $5}' | tr -d '%')`,
    );
    const cpu = parseFloat(stdout.match(/CPU:([\d.]+)/)?.[1] ?? "0");
    const ram = parseFloat(stdout.match(/MEM:([\d.]+)/)?.[1] ?? "0");
    const storage = parseFloat(stdout.match(/DISK:([\d.]+)/)?.[1] ?? "0");
    const uptimeSeconds = Math.floor((Date.now() - new Date(s.createdAt).getTime()) / 1000);
    return res.json({ cpu, ram, storage, network: 0, uptime: uptimeSeconds, status: s.status });
  } catch {
    return res.json({ cpu: 0, ram: 0, storage: 0, network: 0, uptime: 0, status: s.status });
  }
});

export default router;
